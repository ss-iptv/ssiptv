/*
 *  Formula 1 plugin for Movian Media Center
 *
 *  Copyright (C) 2018-2022 deank
 *
 */


(function(plugin) {
    var PREFIX		= plugin.getDescriptor().id;
	var img_path	= plugin.path + "img/";
	var res_path	= plugin.path + "res/";
	var logo		= img_path + "logo.png";
	var f1logo		= img_path + "f1logo.png";
	var f1tvlogo	= img_path + "f1tvlogo.png";
	var io			= require('native/io');

	var user_video  = 'fh';
	var user_audio	= 'au';
	var user_fps	= '50';
	var user_sub	= 0;
	var user_f1ur	= false;
	var temp_fps	= null;
	var temp_cat    = null;

	var obc_video = 'fh';
	var obc_audio = 'fx';
	var obc_fps	  = '50';
	
	var key		  = "";
	var f1_json	  = null;
	var serv_json = null;

	var race_date = "";
	var skyp_date = "";
	var tvl_date  = "";

	var return_to = null;
	var live_last = "";
	var live_last2= "";
	var timestamp = 0;
	var timeout	  = 3600;
	var timeout_live = 3400;
	var hist_max  = 21;
	var live_start= 0;
	var live_end  = 0;
	var live_msg  = "";
	
	var app_ver	  = "ver126";

	var t_pages	  = [];

	var last_hist = "";
	var pre_init  = 0;

	var new_dat	  = 0;
	var	new_cur   = 0;
	var	new_doc   = 0;
	var	new_arc   = 0;

	var last_key = "";

	var timer = setTimeout(timer_func, 1000);

    function setPageHeader(page, title, icon, bg) 
	{
		page.type = "directory";
		page.contents = "items";
		page.metadata.logo = (icon?img_path+icon:logo);
		page.metadata.icon = (icon?img_path+icon:logo);
		page.metadata.title = new showtime.RichText(title);

		if(bg)
			page.metadata.background = bg;
		else
			page.metadata.background = img_path + 'bg/'+Date().replace(/[\D]/g,"").substr(13, 1)+'.jpg';

    }

    var service = plugin.createService(plugin.getDescriptor().title, PREFIX + ":start", "video", true, logo);
	
	var store = plugin.createStore('f1login', true);

	var data_store = plugin.createStore('data_store', true);
	var data_hash = plugin.createStore('data_hash', true);

	var data_hist = plugin.createStore('data_hist', true);

	var data_cur = plugin.createStore('data_cur', true);
	var data_doc = plugin.createStore('data_doc', true);
	var data_arc = plugin.createStore('data_arc', true);

	var data_hash_cur = plugin.createStore('data_hash_cur', true);
	var data_hash_doc = plugin.createStore('data_hash_doc', true);
	var data_hash_arc = plugin.createStore('data_hash_arc', true);

    var settings = plugin.createSettings(plugin.getDescriptor().title, logo, PREFIX);

    settings.createString('key', "Access Key", 'MSKY-FREE-FREE', function(v) {
        service.key = v;
    });

	settings.createBool('f1login', 'Sign-in to F1TV®', true, function(v) {
		service.f1login = v;
    });
	
	settings.createBool('f1tvonly2', 'Show Only F1TV® Content When Signed-in', false, function(v) {
		service.f1tvonly = v;
    });

	settings.createBool('badregion', 'Use From Unsupported F1TV® Region', false, function(v) {
		service.badregion = v;
    });

    settings.createMultiOpt('vod', 'F1® Video Format', [
	        ['hls', 'HLS', true],
	        ['mp4', 'MP4']
        ], function(v) {
        service.vod = v;
    });

	settings.createBool('weekend2', 'F1TV® Weekend Background Image', true, function(v) {
		service.weekend = v;
    });

	settings.createMultiOpt('offset', 'Race Times Clock Offset', [
			[ -8, '-8 Hours'],
			[ -7, '-7 Hours'],
			[ -6, '-6 Hours'],
			[ -5, '-5 Hours'],
			[ -4, '-4 Hours'],
			[ -3, '-3 Hours'],
			[ -2, '-2 Hours'],
			[ -1, '-1 Hour'],
			[  0, 'None', true],
			[  1, '+1 Hours'],
			[  2, '+2 Hours'],
			[  3, '+3 Hours'],
			[  4, '+4 Hours'],
			[  5, '+5 Hours'],
			[  6, '+6 Hours'],
			[  7, '+7 Hours'],
			[  8, '+8 Hours'],

		], function(v) {
		service.offset = v;
	});

	settings.createMultiOpt('quality', 'F1TV® Video Quality', [
			['lq', 'Low'		],
	        ['sd', 'SD'			],
	        ['hd', '720p', true	],
	        ['fh', '1080p'		],			
        ], function(v) {
        service.quality = v;
    });

	settings.createMultiOpt('fps', 'F1TV® Video Framerate', [
			['25', '25 FPS'	],
	        ['50', '50 FPS', true],
        ], function(v) {
        service.fps = v;
    });

	settings.createMultiOpt('audio', 'F1TV® Audio/Language', [
	        ['au', 'English', true],
	        ['fx', 'FX'],
			['es', 'Español'],
			['de', 'Deutsch'],
			['fr', 'Français'],
			['du', 'Dutch'],
			['pt', 'Portuguese'],
        ], function(v) {
        service.audio = v;
    });

	settings.createBool('subs2', 'Subtitles', false, function(v) {
		service.subs = v;
    });

	settings.createBool('whist', 'Watch History', true, function(v) {
		service.whist = v;
    });

	settings.createMultiOpt('ntf2', 'Event Notifications', [
			[  0, 'Never'],
			[  1, 'When Idle'],
			[  2, 'Always', true],
		], function(v) {
		service.ntf = v;
	});

    settings.createMultiOpt('apisrvs2', 'API Server', [
	        ['https://api2.deanbg.com/', 'Default', true],
	        ['https://api.deanbg.com/', 'Secondary']
        ], function(v) {
        service.apisrv = v;
    });

	var f1cat = 
	[
			["video",						"Latest Video"],
			["video.f1-topic-highlights",	"Highlights"],
			["video.f1-topic-feature",		"Feature"],
			["video.f1-topic-interview",	"Interview"],
			["video.f1-topic-onboard",		"OnBoard"],
			["video.f1-topic-esports",		"ESports"],
			["video.f1-topic-archive",		"Archive"],
	];

	var tracks = 
	[
		["Algarve", "Portugal"],
		["Austin", "USA"],
		["Baku", "Azerbaijan"],
		["Barcelona", "Spain"],
		["Catalunya", "Spain"],
		["Dallas", "USA"],
		["Detroit", "USA"],
		["Jeddah", "Saudi Arabia"],
		["Losail", "Qatar"],
		["Hanoi", "Vietnam"],
		["Hockenheim", "Germany"],
		["Hungaroring", "Hungary"],
		["Imola", "Italy"],
		["Interlagos", "Brazil"],
		["Istanbul", "Turkey"],
		["Las Vegas", "USA"],
		["Melbourne", "Australia"],
		["Mexico City", "Mexico"],
		["Monte Carlo", "Monaco"],
		["Montreal", "Canada"],
		["Monza", "Italy"],
		["Mugello", "Italy"],
		["Nurburgring", "Germany"],
		["Nurburgring", "Europe"],
		["Pacific", "Japan"],
		["Paul Ricard", "France"],
		["Sakhir OT", "Bahrain"],
		["Sakhir", "Bahrain"],
		["Shanghai", "China"],
		["Silverstone", "Britain"],
		["Sochi", "Russia"],
		["Spa-Francorchamps", "Belgium"],
		["Spielberg", "Austria"],
		["Suzuka", "Japan"],
		["Valencia", "Spain"],
		["Valencia", "Europe"],
		["Yas Marina Circuit", "Abu Dhabi"],
		["Zandvoort", "Netherlands"],
	];

	var countries =
	[
		["Abu Dhabi"],
		["Argentina"],
		["Australia"],
		["Austria"],
		["Azerbaijan"],
		["Bahrain"],
		["Belgium"],
		["Brazil"],
		["Britain"],
		["Canada"],
		["China"],
		["Europe"],
		["France"],
		["Germany"],
		["Hungary"],
		["India"],
		["Italy"],
		["Japan"],
		["Korea"],
		["Luxembourg"],
		["Malaysia"],
		["Mexico"],
		["Monaco"],
		["Netherlands"],
		["Portugal"],
		["Qatar"],
		["Russia"],
		["San Marino"],
		["Saudi Arabia"],
		["Singapore"],
		["South Africa"],
		["Spain"],
		["Switzerland"],
		["Turkey"],
		//["Vietnam"],
		["USA"]
	];

	function coloredStr(str, color, size) {
		return '<font '+(size?'size="'+size+'" ':'')+'color="' + color + '">' + str + '</font>';
	}

	function update_app(page)
	{
		page.flush();
		return_to = null;
		showtime.notify("Update required, please wait...", 3);
		showtime.notify("Press [BACK] and restart the plugin after 15 seconds...", 10);
		showtime.notify("If you don't see the Formula 1 plugin icon - restart Movian.", 12);
		page.redirect(service.apisrv+PREFIX+'.zip');
	}
	
    plugin.addURI(PREFIX + ":tvch:(.*):(.*)", function(page, ch, title2) 
	{
		if(!serv_json)
		{
			return_to = PREFIX + ":tvch:"+ch+":"+title2;
			page.redirect(PREFIX + ":start"); 
			return;
		}
		var icon = null;
		var logo = null;
		var title = unescape(title2);
		var no_info = "No information available";

		var c_start = parseInt(Date.now()/1000)-1800, 
			c_stop = c_start+3600*4, 
			c_desc = no_info, 
			c_info = "", 
			n_start = c_stop,
			ch_now	= parseInt(Date.now()/1000);

		push_page(page, "tvch");

		if(ch>0 && ch<50)
		{
			icon = (serv_json.ch[ch][1].indexOf('://')>=0?serv_json.ch[ch][1]:img_path + serv_json.ch[ch][1] + ".png");
			nch = (serv_json.ch[ch][4]?serv_json.ch[ch][4]:serv_json.ch[ch][1]);
	        setPageHeader(page, '', img_path + serv_json.ch[ch][1] + ".png");
			title = serv_json.ch[ch][2];

			if(serv_json.tv_prog)
				epg = showtime.JSONDecode(serv_json.tv_prog);

			for(var j=0; j<epg.length; j++)
			{
				if( (serv_json.ch[ch][3] == epg[j].c) &&
					 ( (epg[j].s <= ch_now && epg[j].e >= ch_now ) 
						|| epg[j].s >= ch_now ) )
				{
					c_start	= epg[j].s;
					c_stop	= epg[j].e;
					c_desc	= epg[j].t;
					c_info	= epg[j].i;
					break;
				}
			}

			var ct=new Date((c_start+service.offset*3600)*1000); ct = ct.toString().substr(11, 5);
			var nt=new Date((c_stop +service.offset*3600)*1000); nt = nt.toString().substr(11, 5);

			title = c_desc;
			c_desc = ct+" - "+nt+"  "+c_info;
			icon = serv_json.nows+serv_json.ch[ch][3]+".jpg";
			logo = serv_json.logo+serv_json.ch[ch][3]+".png";
		}
		else
		{
			nch = ch;
	        setPageHeader(page, '');
		}

		page.metadata.glwview =  res_path + "list.view";
		page.flush();

		data = showtime.httpReq(serv_json.bsrv + nch, {
							headers:{
										"User-Agent": serv_json.puag,
									},
							caching: false,
							compression: true,
							nofail: true,
							verifySSL: false,
						}).toString();

		addr1 = data.match(/<iframe[\S\s]*?src=[\"|\']([\S]*?)[\"|\'][\s\S]*?\<\/iframe/);
		if(!addr1)
		{
			showtime.notify("This channel is currently unavailable.", 5);
			return;
		}
		addr1=addr1[1];
		if(addr1[0]=="/") addr1 = "https:" + addr1;

		data = showtime.httpReq(addr1, {
							headers:{
										"User-Agent": serv_json.puag,
									},
							caching: false,
							compression: true,
							nofail: true,
							verifySSL: false,
						}).toString();
		var addpfx = 0;
		var	addrskip = 0;

		addr = data.match(/src=[\"|\']([\S]*?embed[\S]*?)[\"|\']/);
		if(!addr)
			addr = data.match(/src=[\"|\']([\S]*?live[\S]*?)[\"|\']/);
		if(!addr)
		{
			addr = data.match(/.Player\([\s\S]*?[\'|\"](http[\S]*?)[\'|\"]/);
			if(addr)
			{
				addr = addr[1];
				addrskip = 1;
			}
		}
		if(!addr)
		{
			addpfx=1;
			addr = data.match(/\'\/live\/([\S]*?)\"/);
		}
		if(addr && !addrskip)
		{
			addr = addr[1];
			if(addpfx) addr = serv_json.pref + addr;
		}
		
		if(!addr)
		{
			showtime.notify("This channel is currently unavailable.", 5);
			return;
		}

		page.loading = true;
		if(!addrskip)
		{
			for(var j = 0; j < 7; j++)
			{
				data = showtime.httpReq(addr, {
									headers:{
										"Referer": serv_json.bsrv + nch,// addr1,
										"User-Agent": serv_json.puag,
									},
									caching: false,
									compression: true,
									nofail: true,
									verifySSL: false,
								}).toString();

				var re_x = new RegExp(serv_json.re_x, "");
				r = re_x.exec(data);
				var a = null; var s = null; var e = null;

				if(r && r.length>3)
				{
					if(r[2]) a=r[2];
					if(r[3]) s=r[3];
					if(r[4]) e=r[4];
				}

				if(a && s && e) break;
				showtime.sleep(1);
			}

			if(!a || !s || !e)
			{
				page.loading = false;
				showtime.notify("This channel is currently unavailable.", 5);
				return;
			}
			
			addr = serv_json.purl+"/"+a+".m3u8?s="+s+"&e="+e;
		}

		var vrf = null;
		try 
		{
		vrf = showtime.httpReq(addr, {
				headers:{
					"Referer": addr1,
					"User-Agent": serv_json.f1_log_u,
				},
				method: 'HEAD',
				headRequest: true,
				compression: true,
				caching: false,
				noFail: true,
				verifySSL: false,
				debug: false,
			});
		}
		catch(err) {;}

		page.loading = false;
		if(!vrf || (vrf && vrf.statuscode>399))
		{
			showtime.notify("This channel is currently unavailable.", 5);
			return;
		}

		if(serv_json.pdom)
			io.httpInspectorCreate(serv_json.pdom, function(req) {
				//req.setHeader('Referer', addr1);
				req.setHeader('User-Agent', serv_json.puag);
			});

		var videoParams = {
			title: title,
			icon: logo,
			description: unescape(c_desc),
			startts: c_start,
			endts: n_start,
			trackinfo: 0,
			image: icon,
			//canonicalUrl: PREFIX + ":tvch:"+ch,
			sources: [{
				url: "hls:"+addr,
				mimetype: "video/mpeg",
			}],
			no_subtitle_scan: true,
			no_fs_scan: true,
		}
		page.source = 'videoparams:' + JSON.stringify(videoParams);
		page.metadata.glwview =  res_path + "video_page.view";
		page.type = "raw";
		push_page(page, "tvch");
	});

    plugin.addURI(PREFIX + ":tvch2:(.*):(.*)", function(page, ch, title2) 
	{
		if(!serv_json)
		{
			return_to = PREFIX + ":tvch2:"+ch+":"+title2;
			page.redirect(PREFIX + ":start"); 
			return;
		}
        setPageHeader(page, '', img_path + serv_json.ch[ch][1] + ".png");
		page.flush();
		data = showtime.httpReq(serv_json.srv2 + serv_json.ch[ch][4] + serv_json.srv2suf, {
							headers: serv_json.headers2,
							caching: false,
							compression: true,
							nofail: true,
						}).toString();


		t1 = data.replace(/","/g, "").replace(/\\\\/g, "");

		adr = t1.substr((t1.indexOf('return([')+9), 256);
		adr = adr.substr(0, adr.indexOf('"')).replace(/\\/g, "");
		if(serv_json.ch[ch][6])
			adr = adr.replace(serv_json.ch[ch][6], serv_json.ch[ch][7]);
		
		hls = t1.substr((t1.indexOf('["hlsendtime=')+2), 64);
		hls = hls.substr(0, hls.indexOf('"'));

		hash = t1.substr((t1.indexOf('return([')+9), 1024);
		hash = hash.substr(0, hash.indexOf(';'));

		hash1 = hash.substr((hash.indexOf('document.getElementById("')+25), 1024);
		hash1 = hash1.substr(0, hash1.indexOf('"'));

		hash2 = t1.substr(t1.indexOf(hash1) + hash1.length+1, 48);

		var icon = (serv_json.ch[ch][1].indexOf('://')>=0?serv_json.ch[ch][1]:img_path + serv_json.ch[ch][1] + ".png");

		var videoParams = {
			title: serv_json.ch[ch][2],
			icon: icon,
			//canonicalUrl: PREFIX + ":tvch2:"+ch,
			sources: [{
				url: "hls:http:"+adr+hls+hash2,
				mimetype: "video/mpeg",
			}],
			no_subtitle_scan: true,
			no_fs_scan: true,
		}
		page.source = 'videoparams:' + JSON.stringify(videoParams);
		page.metadata.glwview =  res_path + "video_page.view";
		page.type = "raw";

		push_page(page, "tvch");
	});

    plugin.addURI(PREFIX + ":f1:(.*)", function(page, type) 
	{
        setPageHeader(page, 'Formula 1® - ' + f1cat[type][1]);
		page.metadata.glwview =  res_path + "list2.view";
		f1_add_video(page, f1cat[type][0]);
		push_page(page, "f1vd");
	});

    plugin.addURI(PREFIX + ":f1video:(.*)", function(page, video_id) {
        setPageHeader(page, '');
		page.flush();
		push_page(page, "f1vd");

		var f1url = "https://edge.api.brightcove.com/playback/v1/accounts/6057949432001/videos/"+video_id;
		var f1json = showtime.JSONDecode(showtime.httpReq(f1url, {
			method: 'GET',
			noFail: true,
			compression: true,
			headers:{
				"Referer": "https://www.formula1.com/en/video.html",
				"User-Agent": serv_json.f1_log_u,
				"Accept": "application/json;pk=BCpkADawqM1hQVBuXkSlsl6hUsBZQMmrLbIfOjJQ3_n8zmPOhlNSwZhQBF6d5xggxm0t052lQjYyhqZR3FW2eP03YGOER9ihJkUnIhRZGBxuLhnL-QiFpvcDWIh_LvwN5j8zkjTtGKarhsdV",
				},
		}));

		var hls = null;
		var mp4 = null;
		var qual = 0;
		var streams = f1json.sources;

		for (var q in streams) 
		{
			var stream = streams[q];
			if(stream.type == "application/x-mpegURL")
				hls = stream.src;
			if(stream.container == "MP4" && stream.width>qual)
			{
				mp4 = stream.src;
				qual = stream.width;
			}
		}

		if(!hls && !mp4) 
		{
			setPageHeader(page, 'Error');
			showtime.notify("This video is not available.", 5);
			return;
		}
		
		if( (service.vod == "mp4" && mp4) || (!hls && mp4) )
		{

			var videoParams = {
				title: f1json.name,
				image: f1json.thumbnail,
				description: f1json.description,
				canonicalUrl: PREFIX + ":f1video:"+video_id,
				sources: [{
					url: mp4,
					mimetype: "video/mp4",
				}],
				no_subtitle_scan: true,
				no_fs_scan: true,
			}
			page.source = 'videoparams:' + JSON.stringify(videoParams);	
			page.metadata.glwview =  res_path + "video_page.view";
			page.type = "raw";

			push_page(page, "f1vd");
			return;
		}

		/*
        var m3u8 = showtime.httpReq(hls).toString().split('\n');
		var bitrate = 0;
		var hls2 = null;

        for (var i = 0; i < m3u8.length-1; i++) 
		{
            line = m3u8[i].trim();
			if (line.substr(0, 18) == '#EXT-X-STREAM-INF:')
			{
				var params = line.split(',');
				for(var j = 0; j < params.length; j++)
				{
					var params2 = params[j].split('=');
					if(params2.length)
					{
						if(params2[0]=="BANDWIDTH" && parseInt(params2[1])>bitrate)
						{
							hls2 = m3u8[i+1].trim();
							bitrate = parseInt(params2[1]);
						}
					}
				}
			}
		}
		
		if(hls2) hls = hls2;
		*/
		
		if(hls)
		{
			var videoParams = {
				title: f1json.name,
				image: f1json.thumbnail,
				description: f1json.description,
				canonicalUrl: PREFIX + ":f1video:"+video_id,
				sources: [{
					url: "hls:"+hls,
					mimetype: "video/mpeg",
				}],
				no_subtitle_scan: true,
				no_fs_scan: true,
			}
			page.source = 'videoparams:' + JSON.stringify(videoParams);	
			page.metadata.glwview =  res_path + "video_page.view";
			page.type = "raw";

			push_page(page, "f1vd");
			return;
		}
		else
			if(mp4)
				page.redirect(mp4);
	});

	function f1_add_video(page, f1page)
	{
		var re = /data-videoid=\"([\S]*?)\"[\s\S]*?data-src=\"([\S]*?)\"[\s\S]*?video-length">([\s\S]*?)<\/p>[\s\S]*?no-margin\">([\s\S]*?)<\//g;
		
		var doc = "";
		var ids = " ";
		
		page.loading = true;
		
		for(var vpage=1; vpage<5; vpage++)
		{
			doc += showtime.httpReq("https://www.formula1.com/en/"+f1page+"."+vpage+".html", {
						caching: true,
						cachetime: 3600,
						compression: true,
						noFail: true,
						headers:{
							"Referer": "https://www.formula1.com/en/video.html",
							"User-Agent": serv_json.f1_log_u,
							},						
					}).toString().match(/Latest Video<\/h1>([\s\S]*?)"f1-footer"/);
		}
		
		page.loading = false;
		
		var match = re.exec(doc);

		if(match==null) return false;

		while (match) 
		{	
			var video_id = match[1];
			if(ids.indexOf(video_id)>0) {match = re.exec(doc); continue;}
			ids += video_id + " ";
			var image = match[2];
			var title = match[4].replace(/&#39;/gm,"'").replace(/&#34;/gm,'"').replace(/&amp;/gm,"&");
			var duration = parseInt(match[3].split(':')[0])*60+parseInt(match[3].split(':')[1]);

			
			page.appendItem(PREFIX + ":f1video:"+video_id, 'video', {
						icon: image,
						title: title,
						tagline: title,
						duration: duration,
					});
				
			match = re.exec(doc);
		}
		
	}

	function get_cookie(page, channel)
	{
		var data2 = null;
		var is_asset = channel.indexOf("/assets/asse") >= 0;

		try 
		{
			data2 = showtime.httpReq(serv_json.f1_vie_a, {
						headers: {
							"User-Agent":	serv_json.f1_log_u,
							"Accept":		"application/json, text/plain, */*",
							"Content-Type": "application/json",
							"Authorization":"JWT "+store.token,
							"Origin":		"https://f1tv.formula1.com",
							"Referer":		"https://f1tv.formula1.com/en/",
							"X-CountryCode":"zero",
							"Connection": 	"close",
						},
						caching: false,
						compression: true,
						nofail: true,
						method: 'POST',
						postdata: '{"'+(is_asset ? "asset_url" : "channel_url")+'":"'+channel+'"}',
					}).toString();

			if(!data2) return 2;		
			
			data = showtime.JSONDecode(data2);

		}
		catch (err)
		{
			return 2;
		}
					
		try 
		{
			if(!data || (!is_asset && !data.tokenised_url) || (is_asset && !data.objects[0].tata.tokenised_url) ) return 2;

			if(serv_json.f1tv_ur && (user_f1ur || service.badregion))
			{
				data2 = showtime.httpReq(serv_json.f1tv_ur,{
					caching: false,
					compression: true,
					nofail: true,
					method: 'POST',
					postdata: {
						token: store.token,
						asset: '{"'+(is_asset ? "asset_url" : "channel_url")+'":"'+channel+'"}',
						k: service.key,
						h: showtime.deviceId,
						v: app_ver,
					},
				}).toString();

				if(data2=="1")
					return 1;
			}

			master = showtime.httpReq((is_asset ? data.objects[0].tata.tokenised_url : data.tokenised_url), {
						headers: {
							"User-Agent":	serv_json.f1_log_u,
							"Origin":		"https://f1tv.formula1.com",
							"Referer":		"https://f1tv.formula1.com/en/",
							"X-CountryCode":"zero",
							"Connection": 	"close",
						},
						caching: false,
						compression: true,
						nofail: true,
						method: 'GET',
					}).toString();

			if(!master || master.indexOf("EXT")<0)
			{
				return 0;
			}

			return 1;
		}
		catch (err)
		{
			if(serv_json.f1tv_ur && (user_f1ur || service.badregion || showtime.message('Are you currently in unsupported F1TV® region?<br><br>Please enable the option in Settings:<br><br><font size="3" color="#FF1010">Use From Unsupported F1TV® Region</font><br><br>Retry?', true, false)))
			{
				user_f1ur = true;
				service.badregion = true;

				store.token = null;
				store.expire = 0;
				f1_login(page, 0);

				data2 = showtime.httpReq(serv_json.f1tv_ur,{
					caching: false,
					compression: true,
					nofail: true,
					method: 'POST',
					postdata: {
						token: store.token,
						asset: '{"'+(is_asset ? "asset_url" : "channel_url")+'":"'+channel+'"}',
						k: service.key,
						h: showtime.deviceId,
						v: app_ver,
					},
				}).toString();

				if(data2=="1")
				{
					if(!service.badregion)
						showtime.notify("Success...", 2);

					user_f1ur = true;
					service.badregion = true;

					return 1;
				}
			}
			return 0;
		}
	}

	function f1tv_add_events(page, key, key2, cat)
	{
		title = key2.replace("R00 ", "").replace("R99 ", "");
		if(title == "Barcelona" || key2.indexOf("R00 Sakhir")>=0) title = "Pre-Season Test";
		cname = null;
		for(t=0;t<tracks.length;t++) if(key2.indexOf(tracks[t][0])>3) {cname = tracks[t][1]; break;}
		if(!cname) for(c=0;c<countries.length;c++) if(key2.indexOf(countries[c][0])>3) {cname = countries[c][0]; break;}
		if(cname) 
			setPageHeader(page, key+' '+title, "cc/"+cname+".jpg");
		else
			setPageHeader(page, key+' '+title, "f1tvlogo.png");

		page.metadata.glwview =  res_path + "list.view";

		page.options.createMultiOpt('video2', 'Video Quality', 
			[
				['lq', 'Low',		 	(service.quality=="lq"?true:false)],
				['sd', 'SD',			(service.quality=="sd"?true:false)],
				['hd', '720p',			(service.quality=="hd"?true:false)],
				['fh', '1080p',			(service.quality=="fh"?true:false)]
			]
			, function(video2) {
			  user_video = video2;
			}, true);

		page.options.createMultiOpt('fps2', 'Video Framerate', 
			[
				['25', '25 FPS',	 	(service.fps=="25"?true:false)],
				['50', '50 FPS',		(service.fps=="50"?true:false)]
			]
			, function(fps2) {
			  user_fps = fps2;
			}, true);
			
		page.options.createMultiOpt('audio2', 'Audio / Language', 
			[
				['au', 'English', 	(service.audio=="au"?true:false)],
				['fx', 'FX', 		(service.audio=="fx"?true:false)],
				['es', 'Español',	(service.audio=="es"?true:false)],
				['de', 'Deutsch',	(service.audio=="de"?true:false)],
				['fr', 'Français',	(service.audio=="fr"?true:false)],
				['du', 'Dutch',		(service.audio=="du"?true:false)],
				['pt', 'Portuguese',(service.audio=="pt"?true:false)]
			]
			, function(audio2) {
			  user_audio = audio2;
			}, true);

		page.options.createMultiOpt('subs2', 'Subtitles', 
			[
				[1, 'On', 		(service.subs==true?true:false)],
				[0, 'Off', 		(service.subs==false?true:false)]
			]
			, function(subs2) {
			  user_sub = subs2;
			}, true);

		if(key2=="TV") return;
			
		if(key >= serv_json.f1_arch && key < 2099)
		{
			if(key2.indexOf("Support Series")>0) 
				logo2=get_icon(key, key2, "ss");
			else
			{
				logo2 = serv_json.f1_imgs+key+"/"+key2.replace(/\s/g, "%20")+".jpg";
				if(logo2.indexOf("%20•")>2) logo2=logo2.substr(0, logo2.indexOf("%20•"))+".jpg";
			}
			page.metadata.logo = logo2;
			if(service.weekend)
				page.metadata.background = logo2;
		}

		var cat_hlt = 0;
		var cat_anl = 0;
		var cat_prc = 0;
		var cat_sho = 0;
		var cat_ses = 0;

		if(cat == "HLT") page.metadata.title+=" - Highlights";
		else if(cat == "PRC") page.metadata.title+=" - Press";
		else if(cat == "ANL") page.metadata.title+=" - Analysis";
		else if(cat == "SHO") page.metadata.title+=" - Shows";
		else if(cat == "SES") page.metadata.title+=" - Sessions";
		
		if(f1_json[key] && f1_json[key][key2])
		for (var key0 in f1_json[key][key2])
		{
			if(key0.substr(0, 4) == "SKP-") continue;
			
			if(key0.substr(0, 4) == "EXP-")
			{
				search(page, key0.substr(4), 100);
				continue;
			}

			var attr = showtime.JSONDecode(f1_json[key][key2][key0]);
			var aired = "";

			if(!cat)
			{
				if(attr.cat == "HLT") cat_hlt++;
				else if(attr.cat == "ANL") cat_anl++;
				else if(attr.cat == "PRC") cat_prc++;
				else if(attr.cat == "SHO") cat_sho++;
				else if(attr.cat == "SES") cat_ses++;
			}
			else
				if(attr.cat != cat) continue;

			if(key0.substr(0, 4) == "YTP-")
			{
				yid = key0.match(/\[([0-9A-Za-z_-]{10}[048AEIMQUYcgkosw])\]-\[D(\d{2,})\]\-([\S\s]{2,60})/);
				if(yid.length==4)
				{
					if(attr.air)
					{
						l_time = new Date((parseInt(attr.air)+service.offset*3600)*1000);
						aired = "<br><br>Added on: "+l_time.toString().substr(0, 16);
					}
					var item = page.appendItem("ytp:video:"+yid[1], 'video', {
						icon: "http://i.ytimg.com/vi/"+yid[1]+"/mqdefault.jpg",
						title: yid[3],
						duration: parseInt(yid[2]),
						ctitle: new showtime.RichText(coloredStr('YouTube • English', 'AAAAAA', 2)),
						tagline: new showtime.RichText(yid[3]+aired),

					});
					item.ord = attr.ord;
					if(serv_json.isaos)
						item.addOptURL('Play in YouTube', 'youtubeAT:'+yid[1], 'arrow_forward');
				}
				continue;
			}
		
			var has_audio = "English";

			if(attr.sub.indexOf("E")>=0) has_audio = "CC • " + has_audio;
			if(attr.f50) has_audio = "50 FPS • " + has_audio;
			if(attr.aud.indexOf("X")>=0) has_audio+=" • FX";
			if(attr.aud.indexOf("S")>=0) has_audio+=" • Español";
			if(attr.aud.indexOf("G")>=0) has_audio+=" • Deutsch";
			if(attr.aud.indexOf("F")>=0) has_audio+=" • Français";
			if(attr.aud.indexOf("N")>=0) has_audio+=" • Dutch";
			if(attr.aud.indexOf("P")>=0) has_audio+=" • Portuguese";
			if(attr.air)
			{
				l_time = new Date((parseInt(attr.air)+service.offset*3600)*1000);
				aired = "<br><br>Added on: "+l_time.toString().substr(0, 16);
			}
			
			if(!attr.obcs || attr.obcs.length<11)
			{
				var item = page.appendItem(PREFIX + ':f1tv:' + key + ':' + key2 + ':' + key0, 'video', {
					icon: serv_json.f1_imgs+key+"/"+key2.replace(/\s/g, "%20")+"%20-%20"+key0.replace(/\s/g, "%20")+".jpg",
					title: (attr.dur==0?new showtime.RichText(coloredStr(key0, 'ff1010')):key0),
					tagline: new showtime.RichText(key0+aired), // key + ": " + key2 + " - " + key0, 
					duration: attr.dur,
					description: (attr.d?attr.d:""),
					ctitle: new showtime.RichText(coloredStr(has_audio, 'AAAAAA', 2)),
				});

				item.ord = attr.ord;

				if(attr.f50)
				{
					url = PREFIX + ':f1tv_fps:' + key + ':' + key2 + ':' + key0 + ':';
					item.addOptURL("Play in 25 FPS", url+'25', "arrow_forward");
					item.addOptURL("Play in 50 FPS", url+'50', "arrow_forward");
				}
			}
			
			if(attr.obcs && attr.obcs.length>10)
			{
				var item = page.appendItem(PREFIX + ':f1tvobc:' + key + ':' + key2 + ':' + key0 + ":main", 'video', {
					icon: serv_json.f1_imgs+key+"/"+key2.replace(/\s/g, "%20")+"%20-%20"+key0.replace(/\s/g, "%20")+".jpg",
					title: (attr.dur==0?new showtime.RichText(coloredStr(key0, 'ff1010')):key0),
					tagline: new showtime.RichText(key0+aired), // key + ": " + key2 + " - " + key0, 
					duration: attr.dur,
					description: (attr.d?attr.d:""),
					ctitle: new showtime.RichText(coloredStr(has_audio + ' • OBC', 'AAAAAA', 2)),
					canonicalUrl: (attr.dur ? (PREFIX + ":f1tv:"+key+":"+key2+":"+key0) : null),
				});
				item.ord = attr.ord;
			}
		}

		var items=page.getItems();
		var il=items.length;

		if(!il) showtime.notify("No sessions available yet.", 5);

		if(il>1)
		{
			for (var i=0; i<il-1; i++)
			{
				swap=0;
				for (var j=0; j<(il-i-1); j++)
				{
					if(items[j].ord>items[j+1].ord)
					{
						items[j+1].moveBefore(items[j]);
						items=page.getItems();
						swap=1;
					}
				}
				if(swap==0) break;
			}
		}

		if(cat_prc)
		{	page.appendItem(PREFIX + ':f1tv_cat:'+key+':'+key2+':PRC', 'directory', {
			icon: f1tvlogo,
			title: "Press Conference"	});
			items = page.getItems();
			items[items.length-1].moveBefore(items[0]);
		}

		if(cat_sho)
		{	page.appendItem(PREFIX + ':f1tv_cat:'+key+':'+key2+':SHO', 'directory', {
			icon: f1tvlogo,
			title: "Shows"	});
			items = page.getItems();
			items[items.length-1].moveBefore(items[0]);
		}

		if(cat_anl)
		{	page.appendItem(PREFIX + ':f1tv_cat:'+key+':'+key2+':ANL', 'directory', {
			icon: f1tvlogo,
			title: "Analysis"	});
			items = page.getItems();
			items[items.length-1].moveBefore(items[0]);
		}

		if(cat_ses)
		{	page.appendItem(PREFIX + ':f1tv_cat:'+key+':'+key2+':SES', 'directory', {
			icon: f1tvlogo,
			title: "Sessions"	});
			items = page.getItems();
			items[items.length-1].moveBefore(items[0]);
		}

		if(cat_hlt)
		{	page.appendItem(PREFIX + ':f1tv_cat:'+key+':'+key2+':HLT', 'directory', {
			icon: f1tvlogo,
			title: "Highlights"	});
			items = page.getItems();
			items[items.length-1].moveBefore(items[0]);
		}
		temp_cat = null;
	}

	plugin.addURI(PREFIX + ":f1tv_cat:(.*):(.*):(.*)", function(page, key, key2, cat) {
		temp_cat = cat;
		page.redirect(PREFIX + ":f1tv:"+key+":"+key2+":");
	})

	plugin.addURI(PREFIX + ":f1tv_fps:(.*):(.*):(.*):(.*)", function(page, key, key2, key3, fps) {
		temp_fps = fps;
		page.redirect(PREFIX + ":f1tv:"+key+":"+key2+":"+key3);
	});

	plugin.addURI(PREFIX + ":f1tvobc_fps:(.*):(.*):(.*):(.*):(.*)", function(page, key, key2, key3, driver, fps) {
		temp_fps = fps;
		page.redirect(PREFIX + ":f1tvobc:"+key+":"+key2+":"+key3+":"+driver);
	});

    plugin.addURI(PREFIX + ":f1tv:(.*):(.*):(.*)", function(page, key, key2, key3) {

		page.flush();
		var date = new Date();
		var timestamp2 = parseInt(date.getTime()/1000);
		
		if(!f1_json || timestamp2-timestamp>timeout)
		{
			return_to = PREFIX + ":f1tv:"+key+":"+key2+":"+key3;
			page.redirect(PREFIX + ":start"); 
			return;
		}

		page.options.createAction('refresh', "Reload Sessions List", function() 
		{
			timestamp = 0;
			return_to = PREFIX + ":f1tv:"+key+":"+key2+":"+key3;
			page.redirect(PREFIX + ":start"); 
			return;
		});

		if(key && key2 && key3)
		{
			setPageHeader(page, "");

			icon = serv_json.f1_imgs+key+"/"+key2.replace(/\s/g, "%20")+"%20-%20"+key3.replace(/\s/g, "%20")+".jpg";
			page.metadata.background = icon;

			if(!f1_json[key][key2][key3])
			{
				showtime.notify("The event is not available!", 5);
				return;
			}
			
			var attr = (f1_json[key][key2][key3] ? showtime.JSONDecode(f1_json[key][key2][key3]) : null);

			var aired = "";

			if(attr && attr.air)
			{
				l_time = new Date((parseInt(attr.air)+service.offset*3600)*1000);
				aired = " - Added on: "+l_time.toString().substr(0, 16);
			}
			var tk=0;

			if(store.token && service.f1login && store.sstat==1)
				tk=1;
			
			var act_fps = user_fps;
			if(temp_fps)
			{
				act_fps = temp_fps;
				temp_fps = null;
			}

			f1tv_data = showtime.JSONDecode(showtime.httpReq(service.apisrv, {
				postdata: service.key+app_ver+'vod--'+showtime.JSONEncode({c: key, v: key2, e: key3, a: user_audio, q: user_video, f: act_fps, h: showtime.deviceId, t: tk, s: user_sub}),
				method: 'POST',
				caching: false,
				noFail: true,
				compression: true,
			}));

		
			if(f1tv_data)
			{
				if(f1tv_data.m)
					showtime.notify(f1tv_data.m, (f1tv_data.d>2?f1tv_data.d:10));

				if(f1tv_data.update)
				{
					update_app(page);
					return;
				}
				
				if(f1tv_data.api && store.token && service.f1login && store.sstat==1 && !serv_json.f1_syn_2)
				{
					var cookie = get_cookie(page, f1tv_data.api);
					if(cookie == 2)
					{
						store.token = null;
						store.expire = 0;
						f1_login(page, 0);
						if(store.token)
							cookie = get_cookie(page, f1tv_data.api);
					}

					if(cookie!=1)
					{
						var act_fps = user_fps;
						if(temp_fps)
						{
							act_fps = temp_fps;
							temp_fps = null;
						}

						tk=0;
						f1tv_data = showtime.JSONDecode(showtime.httpReq(service.apisrv, {
							postdata: service.key+app_ver+'vod--'+showtime.JSONEncode({c: key, v: key2, e: key3, a: user_audio, q: user_video, f: act_fps, h: showtime.deviceId, t: tk, s: user_sub}),
							method: 'POST',
							caching: false,
							noFail: true,
							compression: true,
						}));
					}
				}
				
				if(f1tv_data.url)
				{
					title = key2.replace("R00 ", "").replace("R99 ", "");
					if(title == "Barcelona" || key2.indexOf("R00 Sakhir")>=0) title = "Pre-Season Test";
					c_desc = key3 + " - " + title + (key!="Feature" ? " (" + key + ")" : "");
					title = title +' - '+key3+" ("+key+")";
					icon = serv_json.f1_imgs+key+"/"+key2.replace(/\s/g, "%20")+"%20-%20"+key3.replace(/\s/g, "%20")+".jpg";
					var c_start = null, c_stop = 0, n_start = 0;
					var get_epg = false;
					var live_msg2 = "";
					
					if(!f1_json[key][key2][key3])
					{
						showtime.notify("The event is not available!", 5);
						return;
					}
					var attr = (f1_json[key][key2][key3] ? showtime.JSONDecode(f1_json[key][key2][key3]) : null);
					if(attr && attr.dur==0 && live_start)
					{
						c_start = live_start;
						c_stop  = live_end;
						n_start = live_end;
						live_msg2 = live_msg;
						c_desc = "LIVE: " + c_desc;
					}
					if(serv_json.tv_key_0)
					{
						for(var i=0; i<serv_json.tv_key_0.length; i++)
							if(key3 == serv_json.tv_key_0[i][0])
							{
								get_epg = serv_json.tv_key_0[i][1]; 
								break; 
							}
					}

					if(get_epg)
					{
						var epg = null;
						live_msg2 = "";

						if(serv_json.tv_prog)
							epg = showtime.JSONDecode(serv_json.tv_prog);

						c_start = parseInt(Date.now()/1000)-1800; 
						c_stop = c_start+3600*4; 
						c_desc = "No information available"; 
						n_start = c_stop;
						ch_now	= parseInt(Date.now()/1000);
						c_info = "";
						
						for(var j=0; j<epg.length; j++)
						{
							if( (get_epg == epg[j].c) &&
								 ( (epg[j].s <= ch_now && epg[j].e >= ch_now ) 
									|| epg[j].s >= ch_now ) )
							{
								c_start	= epg[j].s;
								n_start	= epg[j].e;
								c_desc	= epg[j].t;
								c_info	= epg[j].i;

								break;
							}
						}

						var ct=new Date((c_start+service.offset*3600)*1000); ct = ct.toString().substr(11, 5);
						var nt=new Date((n_start+service.offset*3600)*1000); nt = nt.toString().substr(11, 5);
						icon = serv_json.nows+get_epg+".jpg";
						title = ct+" - "+nt+"  "+c_info;
					}

					var videoParams = {
						title: c_desc,
						//icon: icon,
						description: live_msg2+(attr.d?attr.d:unescape(title))+aired,
						startts: c_start,
						endts: n_start,
						trackinfo: 0,
						image: icon,
						canonicalUrl: (attr.dur ? (PREFIX + ":f1tv:"+key+":"+key2+":"+key3) : null),
						sources: [{
							url: f1tv_data.hls+service.apisrv+f1tv_data.url,
							mimetype: "video/mpeg",
						}],
						subtitles:( (user_sub && f1tv_data.sub)?[{url:f1tv_data.sub, language: "eng", source: "F1TV", title: "Commentary"}]:null),
						no_subtitle_scan: true,
						no_fs_scan: true,
					}

					page.source = 'videoparams:' + JSON.stringify(videoParams);
					page.metadata.glwview =  res_path + "video_page.view";
					page.type = "raw";

					push_page(page, "f1tv_video");

					if(service.whist && key && key2 && key3 && key2!="TV")
					{
						watch_history("add", key, key2, key3);
						setTimeout(hist_func, (60+(parseInt(Math.random()*60)))*1000);
					}
				}
				else
					showtime.notify("Access denied! Please restart the plugin.", 10);
			}
			return;
		}
		
		if(key && key2 && !key3)
		{
			if(temp_cat)
				f1tv_add_events(page, key, key2, temp_cat);
			else
			{
				f1tv_add_events(page, key, key2);
				push_page(page, "f1tv_event", key, key2);
			}
			temp_cat = null;
		}

		if(key && !key2 && !key3)
		{
			setPageHeader(page, 'F1TV® - '+key, "f1tvlogo.png");
			page.metadata.glwview =  res_path + "grid.view";

			var ss = 0;

			for (var key0 in f1_json[key])
			{
				if(key0 == "TV") continue;

				logo2 = logo;
				if(key0.indexOf("Support Series")>0)
				{
					ss = 1;
					continue;
				}

				logo2 = get_icon(key, key0, "f1");
				title = key0.replace("R00 ", "").replace("R99 ", "");
				if(title == "Barcelona" || key0.indexOf("R00 Sakhir")>=0) title = "Pre-Season Test";
				page.appendItem(PREFIX + ':f1tv:' + key + ':' + key0 + ':', 'video', {
					icon: logo2,
					title: title
				});
			}

			if(ss)
			{
				page.appendItem("", "separator", {title: " "}) ;
				page.appendItem("", "separator", {title: " "}) ;

				page.appendItem("", "separator", {
					title: new showtime.RichText(coloredStr('F2® • F3® • Porsche • W Series', "F0F0F0", "+3"))});
				page.appendItem("", "separator", {
					title: new showtime.RichText(coloredStr('Support Series', "E0E0E0", "+2"))});

				page.appendItem("", "separator", {title: " "}) ;

				for (var key0 in f1_json[key])
				{
					if(key0.indexOf("Support Series")<0)
						continue;

					logo2 = get_icon(key, key0, "ss");
					logo2 = logo2.replace(/\s/g, "%20");

					page.appendItem(PREFIX + ':f1tv:' + key + ':' + key0 + ':', 'video', {
						icon: logo2,
						title: key0.substr(4).replace(" • Support Series", ""),
					});
				}
			}
		}
		push_page(page, "f1tv_ses", key);
	});

	plugin.addURI(PREFIX + ":f1tvobc:(.*):(.*):(.*):(.*)", function(page, key, key2, key3, driver) {

		page.flush();
		var date = new Date();
		var timestamp2 = parseInt(date.getTime()/1000);
		if(!f1_json || timestamp2-timestamp>timeout)
		{
			return_to = PREFIX + ":f1tvobc:"+key+":"+key2+":"+key3+":"+driver;
			page.redirect(PREFIX + ":start"); 
			return;
		}

		
		if(key && key2 && key3 && driver=="main")
		{
			setPageHeader(page, key+' '+key2+' - '+key3, "f1tvlogo.png", serv_json.f1_imgs+key+"/"+key2.replace(/\s/g, "%20")+"%20-%20"+key3.replace(/\s/g, "%20")+".jpg");

			page.metadata.glwview =  res_path + "list.view";

			if(!f1_json[key][key2][key3])
			{
				showtime.notify("The event is not available!", 5);
				return;
			}
			var attr = (f1_json[key][key2][key3] ? showtime.JSONDecode(f1_json[key][key2][key3]) : null);

			page.options.createMultiOpt('video3', 'Video Quality', 
				[
					['lq', 'Low',		 	(obc_video=="lq"?true:false)],
					['sd', 'SD',			(obc_video=="sd"?true:false)],
					['hd', '720p',			(obc_video=="hd"?true:false)],
					['fh', '1080p',			(obc_video=="fh"?true:false)]
				]
				, function(video3) {
				  obc_video = video3;
				}, true);

			page.options.createMultiOpt('fps3', 'Video Framerate', 
			[
				['25', '25 FPS',		(obc_fps=="25"?true:false)],
				['50', '50 FPS',		(obc_fps=="50"?true:false)]
			]
			, function(fps3) {
			  obc_fps = fps3;
			}, true);
				
			page.options.createMultiOpt('audio3', 'Audio / Language', 
				[
					['au', 'English', 	(obc_audio=="au"?true:false)],
					['fx', 'FX', 		(obc_audio=="fx"?true:false)],
					['es', 'Español',	(obc_audio=="es"?true:false)],
					['de', 'Deutsch',	(obc_audio=="de"?true:false)],
					['fr', 'Français',	(obc_audio=="fr"?true:false)],
					['du', 'Dutch',		(obc_audio=="du"?true:false)],
					['pt', 'Portuguese',(obc_audio=="pt"?true:false)]
				]
				, function(audio3) {
				  obc_audio = audio3;
				}, true);

			var aired = "";
			var has_audio = "English";

			if(attr.sub.indexOf("E")>=0) has_audio = "CC • " + has_audio;
			if(attr.f50) has_audio = "50 FPS • " + has_audio;
			if(attr.aud.indexOf("X")>=0) has_audio+=" • FX";
			if(attr.aud.indexOf("S")>=0) has_audio+=" • Español";
			if(attr.aud.indexOf("G")>=0) has_audio+=" • Deutsch";
			if(attr.aud.indexOf("F")>=0) has_audio+=" • Français";
			if(attr.aud.indexOf("N")>=0) has_audio+=" • Dutch";
			if(attr.aud.indexOf("P")>=0) has_audio+=" • Portuguese";
			if(attr.air)
			{
				l_time = new Date((parseInt(attr.air)+service.offset*3600)*1000);
				aired = "<br><br>Added on: "+l_time.toString().substr(0, 16);
			}
			
			var item = page.appendItem(PREFIX + ':f1tv:' + key + ':' + key2 + ':' + key3, 'video', {
				icon: serv_json.f1_imgs+key+"/"+key2.replace(/\s/g, "%20")+"%20-%20"+key3.replace(/\s/g, "%20")+".jpg",
				title: (attr.dur==0?new showtime.RichText(coloredStr(key3, 'ff1010')):key3),
				tagline: new showtime.RichText(key3+aired), // key + ": " + key2 + " - " + key0, 
				duration: attr.dur,
				description: (attr.d?attr.d:""),
				ctitle: new showtime.RichText(coloredStr(has_audio, 'AAAAAA', 2)),
			});

			item.ord = attr.ord;

			if(attr.f50)
			{
				url = PREFIX + ':f1tv_fps:' + key + ':' + key2 + ':' + key3 + ':';
				item.addOptURL("Play in 25 FPS", url+'25', "arrow_forward");
				item.addOptURL("Play in 50 FPS", url+'50', "arrow_forward");
			}
			
			var drivers = showtime.JSONDecode(attr.obcs);
			for(d=0;d<drivers.length;d++)
			{
				var item = page.appendItem(PREFIX + ':f1tvobc:' + key + ':' + key2 + ':' + key3 + ":"+drivers[d], 'video', {
						icon: serv_json.f1_imgs + "drivers/"+key+"/"+escape(drivers[d])+".png",
						title: drivers[d].replace("000 FIA ", ""),
						tagline: (drivers[d].indexOf("000")<0)?new showtime.RichText(drivers[d]+"<br><br>Onboard Camera"):"",
						duration: attr.dur,
						ctitle: new showtime.RichText(coloredStr((drivers[d].indexOf("000")<0)?"OnBoard":"", 'AAAAAA')), // drivers[d].substr(8)
					});

				item.url = PREFIX + ':f1tvobc:' + key + ':' + key2 + ':' + key3 + ":"+drivers[d];

				if(attr.f50)
				{
					url = PREFIX + ':f1tvobc_fps:' + key + ':' + key2 + ':' + key3 + ":"+drivers[d]+":";
					item.addOptURL("Play in 25 FPS", url+'25', "arrow_forward");
					item.addOptURL("Play in 50 FPS", url+'50', "arrow_forward");
				}

			}
			push_page(page, "f1ob");
			return;
		}
		
		if(key && key2 && key3 && driver!="main")
		{
			setPageHeader(page, driver);

			var tk=0;
			if(store.token && service.f1login && store.sstat==1)
				tk=1;

			var act_fps = obc_fps;
			if(temp_fps)
			{
				act_fps = temp_fps;
				temp_fps = null;
			}
			
			f1tv_data = showtime.JSONDecode(showtime.httpReq(service.apisrv, {
				postdata: service.key+app_ver+'vod--'+showtime.JSONEncode({c: key, v: key2, e: key3, d: driver, a: obc_audio, q: obc_video, f: act_fps, h: showtime.deviceId, t: tk}),
				method: 'POST',
				caching: false,
				noFail: true,
				compression: true,
			}));
			
			if(f1tv_data)
			{
				if(f1tv_data.m)
					showtime.notify(f1tv_data.m, (f1tv_data.d>2?f1tv_data.d:10));

				if(f1tv_data.update)
				{
					update_app(page);
					return;
				}
				
				if(f1tv_data.api && store.token && service.f1login && store.sstat==1)
				{
					var cookie = get_cookie(page, f1tv_data.api);
					if(cookie == 2)
					{
						store.token = null;
						store.expire = 0;
						f1_login(page, 0);
						if(store.token)
							cookie = get_cookie(page, f1tv_data.api);
					}

					if(cookie!=1)
					{
						tk=0;
						f1tv_data = showtime.JSONDecode(showtime.httpReq(service.apisrv, {
							postdata: service.key+app_ver+'vod--'+showtime.JSONEncode({c: key, v: key2, e: key3, d: driver, a: obc_audio, q: obc_video, f: act_fps, h: showtime.deviceId, t: tk}),
							method: 'POST',
							caching: false,
							noFail: true,
							compression: true,
						}));
					}
				}
				
				if(f1tv_data.url)
				{
					if(!f1_json[key][key2][key3])
					{
						showtime.notify("The event is not available!", 5);
						return;
					}
					var attr = (f1_json[key][key2][key3] ? showtime.JSONDecode(f1_json[key][key2][key3]) : null);

					var videoParams = {
						title: key2+' - '+key3+" ("+driver.replace("000 FIA ", "")+")",
						icon: (driver.indexOf("000 FIA ")>=0?null:serv_json.f1_imgs + "drivers/"+key+"/"+escape(driver)+".png"),
						canonicalUrl: (attr.dur ? (PREFIX + ":f1tv:"+key+":"+key2+":"+key3) : null),
						sources: [{
							url: f1tv_data.hls+service.apisrv+f1tv_data.url,
							mimetype: "video/mpeg",
						}],
						no_subtitle_scan: true,
						no_fs_scan: true,
					}
					page.source = 'videoparams:' + JSON.stringify(videoParams);
					page.metadata.glwview =  res_path + "video_page.view";
					page.type = "raw";

					push_page(page, "f1ob");
				}
				else
					showtime.notify("Access denied!", 10);
			}
			return;
		}
		
	});

    plugin.addURI(PREFIX + ":f1news:(.*):(.*)", function(page, news, img) {

		page.type = "directory";
		page.contents = "items";
		page.metadata.glwview =  res_path + "list2.view";
		page.metadata.title = 'F1® - News';
		page.metadata.logo = logo;
		page.metadata.icon = logo;

		if(!serv_json)
		{
			return_to = PREFIX + ":f1news:"+news+":"+img;
			page.redirect(PREFIX + ":start"); 
			return;
		}
		page.loading = true;
		var doc = "";

		if(!news)
		{
			page.metadata.background = img_path + 'bg/'+Date().replace(/[\D]/g,"").substr(13, 1)+'.jpg';

			var news_page = [ "News", "Technical", "Feature", "Opinion", "Report", "Interview", "Podcast"]; //"Podcast"

			var re = /f1-latest-listing--grid-item[\s\S]*?href="([\S]*?)"[\s\S]*?data-src="([\S]*?)"[\s\S]*?<p class=\"[^misc][\s\S]*?">([\s\S]*?)<\/p>[\s]*?<\/div>/g;

			for(var vpage=0; vpage<news_page.length; vpage++)
			{
				if(vpage) page.appendItem("", "separator", {title: new showtime.RichText(coloredStr(news_page[vpage], "F0F0F0", "+2"))});

				doc = showtime.httpReq("https://www.formula1.com/en/latest/all."+news_page[vpage].toLowerCase()+".html", {
							caching: true,
							cachetime: 3600,
							compression: true,
							noFail: true,
							headers:{
								"Referer": "https://www.formula1.com/en/latest",
								"User-Agent": serv_json.f1_log_u,
								},						
						}).toString();

				var match = re.exec(doc);
				var articles = 0;
				
				while (match) 
				{	
					if(match[1].indexOf("google")<0)
					{
						var title = match[3].replace(/&#39;/gm,"'").replace(/&#34;/gm,'"').replace(/&amp;/gm,"&").trim();
						if(articles<6)
						page.appendItem(PREFIX + ":f1news:"+escape(match[1].trim())+":"+escape(match[2].trim()), 'directory', {
									icon: match[2],
									title: title,
									description: title,
									duration: "",
								});
						articles++;
					}
					match = re.exec(doc);
				}
				page.loading = false;
			}
		}
		else
		{
			var re = /"f1-article--rich-text">([\S\s]*?)<\/div>/g;
			var re_title = /og:description" content="([\S\s]*?)"\/>/g;
			var re_video = /data-videoid=\"([\S]*?)\"[\s\S]*?video-caption[\s\S]*?>([\s\S]*?)</g;
			var re_audio = /embeds\.audioboom\.com\/posts\/([\d]*?)\//g;

			doc = showtime.httpReq("https://www.formula1.com"+unescape(news), {
							caching: true,
							cachetime: 3600,
							compression: true,
							noFail: true,
							headers:{
								"Referer": "https://www.formula1.com/en/latest",
								"User-Agent": serv_json.f1_log_u,
								},						
						}).toString();

			var match = re.exec(doc);

			if(match==null) return false;

			if(img)
				page.metadata.background = unescape(img);
			else
				page.metadata.background = img_path + 'bg/'+Date().replace(/[\D]/g,"").substr(13, 1)+'.jpg';

			var tag = re_title.exec(doc);
			if(tag)
			{
				tag = tag[1];
				tag = new showtime.RichText('<font size="+5">'+tag.replace(/&#39;/gm,"'").replace(/&#34;/gm,'"').replace(/&amp;/gm,"&").trim()+"</font><hr>");
				page.appendItem('', 'news', { title: tag });
			}
			var vids = null;
			while(1)
			{
				vids = re_video.exec(doc);
				if(!vids) break;
				title = vids[2].trim().replace(/&#39;/gm,"'").replace(/&#34;/gm,'"').replace(/&amp;/gm,"&").trim();
				page.appendItem(PREFIX + ":f1video:"+vids[1], 'videonews', {
					icon: logo,
					title: title,
				});
			}

			var podcast = re_audio.exec(doc);
			if(podcast && podcast[1])
				page.appendItem('https://audioboom.com/posts/'+podcast[1]+'.mp3', 'audio', {
					icon: logo,
					title: "Click Here to Listen to the Podcast"
				});

			var br = "\n";
			while (match) 
			{	
				var title = match[1].replace(/&#39;/gm,"'").replace(/&#34;/gm,'"').replace(/&amp;/gm,"&").replace(/<p>/gm,"").replace(/<strong>/gm,"").replace(/<\/p>/gm,"").replace(/<\/strong>/gm,"").replace(/\n\n\n/gm,'\n\n').replace(/\n\n\n/gm,'\n\n').replace(/\n\n\n/gm,'\n\n').replace(/\n\n\n/gm,'\n\n').replace(/\n\n\n/gm,'\n\n').trim();
				var paragraphs = title.split('\n\n');
				if(paragraphs.length>3)
				{
					for(var pa=0; pa<paragraphs.length; pa++)
						if(paragraphs[pa].indexOf("READ MORE:")<0)
						{
							page.appendItem('', 'news', { title: new showtime.RichText(br+paragraphs[pa]+"\n\n") });
							br = "";
						}
				}
				else
					page.appendItem('', 'news', { title: new showtime.RichText(br+title+"\n\n") });

				br = "";
				match = re.exec(doc);
			}

			page.appendItem(page.metadata.background, 'image');

			page.appendItem('', 'news', { title: ' ' });
		}
		page.loading = false;
		push_page(page, "f1nw");
	});

    plugin.addURI(PREFIX + ":standings:(.*):(.*)", function(page, year, type) 
	{
		if(!serv_json)
		{
			return_to = PREFIX + ":standings:"+year+":"+type;
			page.redirect(PREFIX + ":start"); 
			return;
		}
		if(!year) 
		{
			year = 2021;
			for(var i = year-1; i>2016; i--)
			{
				page.appendItem(PREFIX + ":standings:"+i+":", 'directory', {
					icon: logo,
					title: i+" Standings"
				});
			}
			page.appendItem("", "separator", {title:""});
		}
		setPageHeader(page, 'F1® - '+year+' Season Standings');
		page.metadata.glwview =  res_path + "list2.view";
		page.loading = true;
		var doc = "";

		if(type != "teams")
				page.appendItem(PREFIX + ":standings:"+year+":teams", 'directory', {
					icon: logo,
					title: "Teams"
				});
		else
		{
			var re = /class="dark">([\d]{1,2})<[\s\S]*?ArchiveLink">([\S\s]*?)<[\s\S]*?dark bold">([\S\s]*?)</g;

			doc = showtime.httpReq("https://www.formula1.com/en/results.html/"+year+"/team.html", {
						caching: true,
						cachetime: 3600,
						compression: true,
						noFail: true,
						headers:{
							"Referer": "https://www.formula1.com/en/latest",
							"User-Agent": serv_json.f1_log_u,
							},						
					}).toString();

			var match = re.exec(doc);
			var p = 1;
			
			while (match) 
			{	
				var team = match[2];
				var title = p+" - "+team+" - "+match[3]+" pts";
				page.appendItem(serv_json.f1_imgs + "teams/"+year+"/"+escape(team)+".png", 'video', {
							icon: serv_json.f1_imgs + "teams/"+year+"/"+escape(team)+".png",
							title: title,
							description: "Position: "+p+"\n\nTeam: "+team+"\n\nPoints: "+match[3],
							duration: "",
						});
				p++;
				match = re.exec(doc);
			}
			if(p==1)
				page.appendItem("", "separator", {
					title: new showtime.RichText(coloredStr('Standings not available yet', "D0D0D0", "+1"))});

			page.loading = false;
			push_page(page, "f1st");
			return;
		}


		var re = /hide-for-tablet">([\s\S]*?)<[\s\S]*?hide-for-mobile">([\s\S]*?)<[\s\S]*?href=[\s\S]*?>([\s\S]*?)<[\s\S]*?bold">([\S]*?)</g;

		doc = showtime.httpReq("https://www.formula1.com/en/results.html/"+year+"/drivers.html", {
					caching: true,
					cachetime: 3600,
					compression: true,
					noFail: true,
					headers:{
						"Referer": "https://www.formula1.com/en/latest",
						"User-Agent": serv_json.f1_log_u,
						},						
				}).toString();

		var match = re.exec(doc);
		var p = 1;
		
		while (match) 
		{	
			var driver = match[1]+" "+match[2];
			driver = driver.replace("Kimi Räikkönen", "Kimi Raikkonen");
			var title = p+" - "+driver+" ("+match[3]+") "+match[4]+" pts";
			page.appendItem(serv_json.f1_imgs + "drivers/"+year+"/"+escape(driver)+".png", 'video', {
						icon: serv_json.f1_imgs + "drivers/"+year+"/"+escape(driver)+".png",
						title: title,
						description: "Position: "+p+"\n\nDriver: "+driver+"\n\nTeam: "+match[3]+"\n\nPoints: "+match[4],
						duration: "",
					});
			p++;
			match = re.exec(doc);
		}
		if(p==1)
			page.appendItem("", "separator", {
				title: new showtime.RichText(coloredStr('Standings not available yet', "D0D0D0", "+1"))});

		page.loading = false;
		push_page(page, "f1st");
	});

	function f1tv_add_main(page)
	{
		setPageHeader(page, 'F1TV® - Live & Archive', "f1tvlogo.png");
		page.metadata.glwview =  res_path + "list2.view";
		
		page.appendItem(PREFIX + ':f1cat:f1tv:live', 'directory', {
			icon: f1tvlogo,
			title: "Live"
		});
		
		page.appendItem(PREFIX + ':f1cat:f1tv:vod', 'directory', {
			icon: f1tvlogo,
			title: "Archive"
		});

		page.appendItem(PREFIX + ':srch:', 'directory', {
			icon: f1tvlogo,
			title: "Search F1TV®"
		});

		if(service.whist)
		page.appendItem(PREFIX + ':hist', 'directory', {
			icon: f1tvlogo,
			title: "Watch History"
		});

		if(serv_json.f1_lytv)
		page.appendItem(PREFIX + ':f1cat:f1tv:ytv', 'directory', {
			icon: img_path + "yt.svg",
			title: "Latest"
		});

		if(serv_json.f1_last)
		{
			page.appendItem("", "separator", {
				title: new showtime.RichText(coloredStr('Latest F1TV® On-Demand Videos', "D0D0D0", "+1"))});
			page.appendItem("", "separator") ;

			var last_10 = showtime.JSONDecode(serv_json.f1_last);
			for(var d = 0; d < last_10.length; d++)
			{
				if(last_10[d][2].substr(0, 4) == "YTP-")
				{
					yid = last_10[d][2].match(/\[([0-9A-Za-z_-]{10}[048AEIMQUYcgkosw])\]-\[D(\d{2,})\]\-([\S\s]{2,60})/);
					if(yid.length==4)
					{
						l_time = new Date((parseInt(last_10[d][4])+service.offset*3600)*1000);
						aired = "<br><br>Added on: "+l_time.toString().substr(0, 16);

						l_year = last_10[d][0];
						l_event = last_10[d][1].replace("R00 ", "").replace("R99 ", "");
						if(l_event == "Barcelona" || last_10[d][1].indexOf("R00 Sakhir")>=0) l_event = "Pre-Season Test";
						l_session = yid[3]; if(l_year!="Feature") l_title = l_year + " - " + l_event + " - " + l_session; else l_title = l_session; l_title = l_title.replace(" • Support Series", "");

						var item = page.appendItem("ytp:video:"+yid[1], 'video', {
							icon: "http://i.ytimg.com/vi/"+yid[1]+"/mqdefault.jpg",
							title: l_title,
							duration: parseInt(yid[2]),
							ctitle: new showtime.RichText(coloredStr('YouTube • English', 'AAAAAA', 2)),
							tagline: new showtime.RichText(yid[3]+aired),

						});
						if(serv_json.isaos)
							item.addOptURL('Play in YouTube', 'youtubeAT:'+yid[1], 'arrow_forward');

						item.addOptURL("Open Event '" + l_year + " - " + l_event +"'", PREFIX + ':f1tv:' + l_year + ':' + last_10[d][1] + ':', "search");
						item.addOptURL("Open " + (l_year == "Feature" ? "Category" : "Season") + " '" + l_year + "'", PREFIX + ':f1tv:' + l_year + '::', "search");
					}
					continue;
				}

				l_year = last_10[d][0];
				l_event = last_10[d][1].replace("R00 ", "").replace("R99 ", "");
				if(l_event == "Barcelona" || last_10[d][1].indexOf("R00 Sakhir")>=0) l_event = "Pre-Season Test";
				l_session = last_10[d][2]; if(l_year!="Feature") l_title = l_year + " - " + l_event + " - " + l_session; else l_title = l_session; l_title = l_title.replace(" • Support Series", "");
				l_dur = parseInt(last_10[d][3]);
				l_time = new Date((parseInt(last_10[d][4])+service.offset*3600)*1000);
				attr = null;
				if(f1_json[l_year] && f1_json[l_year][last_10[d][1]] && f1_json[l_year][last_10[d][1]][l_session])
				{
					try	{ attr = (f1_json[l_year][last_10[d][1]][l_session] ? showtime.JSONDecode(f1_json[l_year][last_10[d][1]][l_session]) : null); }
					catch (err)	{attr = null;}

					var item = page.appendItem(PREFIX + ':f1tv:' + l_year + ':' + last_10[d][1] + ':' + l_session, 'video', {
						icon: serv_json.f1_imgs+l_year+"/"+last_10[d][1].replace(/\s/g, "%20")+"%20-%20"+l_session.replace(/\s/g, "%20")+".jpg",
						title: new showtime.RichText(l_title),
						tagline:  new showtime.RichText(l_year + " - " + l_event + '<br><br>' + l_session + '<br><br> Added on: ' + l_time.toString().substr(0, 16), 'E0E0E0', 3),
						duration: l_dur,
						description: ((attr && attr.d)?attr.d:"")
					});

					if(attr && attr.f50)
					{
						url = PREFIX + ':f1tv_fps:' + l_year + ':' + last_10[d][1] + ':' + l_session + ':';
						item.addOptURL("Play in 25 FPS", url+'25', "arrow_forward");
						item.addOptURL("Play in 50 FPS", url+'50', "arrow_forward");
					}

					item.addOptURL("Open Event '" + l_year + " - " + l_event +"'", PREFIX + ':f1tv:' + l_year + ':' + last_10[d][1] + ':', "search");
					item.addOptURL("Open " + (l_year == "Feature" ? "Category" : "Season") + " '" + l_year + "'", PREFIX + ':f1tv:' + l_year + '::', "search");
				}
			}
		}
		
		if(serv_json.f1tv_m1 && serv_json.f1tv_d1)
			showtime.notify(serv_json.f1tv_m1, serv_json.f1tv_d1);
		if(serv_json.f1tv_m2 && serv_json.f1tv_d2)
			showtime.notify(serv_json.f1tv_m2, serv_json.f1tv_d2);
		
		return;
	}

	function f1tv_add_live(page)
	{
		setPageHeader(page, 'F1TV® - Live', "f1tvlogo.png");
		page.metadata.glwview =  res_path + "list.view";
		
		if(serv_json.live_m1 && serv_json.live_d1)
			showtime.notify(serv_json.live_m1, serv_json.live_d1);
		if(serv_json.live_m2 && serv_json.live_d2)
			showtime.notify(serv_json.live_m2, serv_json.live_d2);
		
		if(serv_json.ch)
		for (var ch in serv_json.ch) 
		{
			if(serv_json.ch[ch][0]==10)
			{
				icon = (serv_json.ch[ch][1].indexOf('://')>=0?serv_json.ch[ch][1]:img_path + serv_json.ch[ch][1] + ".png");
				page.appendItem(serv_json.ch[ch][3], 'video', {
					icon:  icon,
					image: serv_json.ch[ch][6],
					title: serv_json.ch[ch][2],
					description: new showtime.RichText( (icon.indexOf("SkySpF1.uk")>0 && skyp_date)?skyp_date:serv_json.ch[ch][4]+race_date ),
					ctitle: new showtime.RichText(coloredStr(serv_json.ch[ch][5], 'AAAAAA', 2)),
				});
			}
			if(serv_json.ch[ch][0]==80)
			{
				search_events(page, serv_json.ch[ch][1], race_date);
			}

			if(serv_json.ch[ch][0]==81)
			{
				page.appendItem("", "separator", {
					title: new showtime.RichText(coloredStr(serv_json.ch[ch][1], serv_json.ch[ch][2], serv_json.ch[ch][3]))});
			}
		}
		return;
	}

	function watch_history(action, key1n, key2n, key3n)
	{
		var curr_hist = [];

		var date = new Date();
		var w_time = parseInt(date.getTime()/1000);
		var entries = 0;

		if(data_hist && data_hist.data)
		{
			var data_hist_t = null;	try {data_hist_t = showtime.JSONDecode(data_hist.data);} catch (err){;}
			
			if(data_hist_t && data_hist_t.length)
			for (var widx in data_hist_t)
			{
				key1=data_hist_t[widx].key1; key2=data_hist_t[widx].key2; key3=data_hist_t[widx].key3; watched=data_hist_t[widx].watched;
				if(key2=="TV") continue;
				if( f1_json && f1_json[key1] && f1_json[key1][key2] && f1_json[key1][key2][key3] &&
					(!(key1==key1n && key2==key2n && key3==key3n))
					)
				{
					curr_hist.push({
						key1: key1,
						key2: key2,
						key3: key3,
						watched: watched
					});
					entries++;
					if(entries>hist_max) break;
				}
			}
		}

		if(action == "add")
			curr_hist.unshift({
				key1: key1n,
				key2: key2n,
				key3: key3n,
				watched: w_time
			});

		data_hist.data = showtime.JSONEncode(curr_hist);
	}

	plugin.addURI(PREFIX + ":srch:(.*)", function(page, q)
	{
		page.flush();

		if(!serv_json)
		{
			return_to = PREFIX + ":srch:" + q;
			page.redirect(PREFIX + ":start"); 
			return;
		}

		if(q)
		{
			setPageHeader(page, 'F1TV® - ' + q, "cc/"+q+".jpg");
			page.metadata.glwview =  res_path + "list.view";
		}
		else
		{
			setPageHeader(page, 'F1TV® - Search', "f1tvlogo.png");
			page.metadata.glwview =  res_path + "grid.view";
			page.appendItem(PREFIX + ":search:", 'search', {
				title: 'Search F1TV® (i.e. Tech Talk, Race in 30, Porsche 2019, Hamilton, Valencia, Spain Race)'
			});
			page.appendItem("", "separator", {title:""});

			for(var i=0; i<countries.length; i++)
			{
				page.appendItem(PREFIX + ':srch:'+countries[i][0], 'directory', {
					icon: img_path + "cc/"+countries[i][0]+".jpg",
					title: countries[i][0]
				});
			}
			push_page(page, "srch");
			return;
		}
		var qs = {year:2021, prfx: "", tagl: "", src1:q, cnt:50};
		search_events(page, qs, "");
		if(!page.getItems().length)
			showtime.notify("No sessions available yet.", 5);
		push_page(page, "srch");
	});

	plugin.addURI(PREFIX + ":hist", function(page)
	{
		page.flush();
		setPageHeader(page, 'F1TV® - Watch History', "f1tvlogo.png");
		page.metadata.glwview =  res_path + "list.view";
		var date = new Date();
		var timestamp2 = parseInt(date.getTime()/1000);

		page.options.createAction('clearhist', "Clear History", function() 
		{
			timestamp = 0;
			page.flush();
			data_hist = [];
			if(serv_json && serv_json.f1_shist)
			showtime.httpReq(service.apisrv, {
				postdata: service.key+app_ver+'whist'+showtime.JSONEncode({h: showtime.deviceId, wh:""}),
				method: 'POST',
				caching: false,
				noFail: true,
				compression: true,
			});
			page.redirect(PREFIX + ":hist"); 
			return;
		});	

		if(!f1_json || timestamp2-timestamp>timeout)
		{
			return_to = PREFIX + ":hist";
			page.redirect(PREFIX + ":start"); 
			return;
		}

		if(data_hist && data_hist.data)
		{
			var data_hist_t = null;	try {data_hist_t = showtime.JSONDecode(data_hist.data);} catch (err){;}
			
			if(data_hist_t && data_hist_t.length)
			{
				for (var widx in data_hist_t)
				{
					key1=data_hist_t[widx].key1; key2=data_hist_t[widx].key2; key3=data_hist_t[widx].key3; watched=data_hist_t[widx].watched;
					if(key2=="TV") continue;
					if(f1_json[key1] && f1_json[key1][key2] && f1_json[key1][key2][key3])
					{
						var attr = showtime.JSONDecode(f1_json[key1][key2][key3]);
						
						var has_audio="English";
						var aired = "";
						if(attr.sub.indexOf("E")>=0) has_audio = "CC • " + has_audio;
						if(attr.f50) has_audio = "50 FPS • " + has_audio;
						if(attr.aud.indexOf("X")>=0) has_audio+=" • FX";
						if(attr.aud.indexOf("S")>=0) has_audio+=" • Español";
						if(attr.aud.indexOf("G")>=0) has_audio+=" • Deutsch";
						if(attr.aud.indexOf("F")>=0) has_audio+=" • Français";
						if(attr.aud.indexOf("N")>=0) has_audio+=" • Dutch";
						if(attr.aud.indexOf("P")>=0) has_audio+=" • Portuguese";
						if(attr.air)
						{
							l_time = new Date((parseInt(attr.air)+service.offset*3600)*1000);
							aired = " - Added on: "+l_time.toString().substr(0, 16);
						}

						w_time = new Date((parseInt(watched)+service.offset*3600)*1000);

						l_year = key1;
						l_event = key2.replace("R00 ", "").replace("R99 ", "");
						if(l_event == "Barcelona" || key2.indexOf("R00 Sakhir")>=0) l_event = "Pre-Season Test";
						l_session = key3; if(l_year!="Feature") l_title = l_year + " - " + l_event + " - " + l_session; else l_title = l_session; l_title = l_title.replace(" • Support Series", "");

						var item = page.appendItem(PREFIX + ':f1tv:' + key1 + ':' + key2 + ':' + key3, 'video', {
							icon: serv_json.f1_imgs+key1+"/"+key2.replace(/\s/g, "%20")+"%20-%20"+key3.replace(/\s/g, "%20")+".jpg",
							title: (attr.dur==0?new showtime.RichText(coloredStr(l_title, 'ff1010')):l_title),
							tagline: new showtime.RichText(l_year + " - " + l_event+"<br><br>"+l_session+"<br><br>Watched on: "+w_time.toString().substr(0, 16)),
							duration: attr.dur,
							description: (attr.d?attr.d:""),
							ctitle: new showtime.RichText(coloredStr(has_audio+aired, 'AAAAAA', 2)),
						});
						item.y=l_year;
						item.e=key2;
						item.s=l_session;
						
						item.addOptAction("Remove from History", function ()
							{
								watch_history('del', this.y, this.e, this.s ); 
								setTimeout(hist_func, 15*1000); 
								page.redirect(PREFIX + ":hist");
							}.bind(item), "delete");

						if(attr && attr.f50)
						{
							url = PREFIX + ':f1tv_fps:' + key1 + ':' + key2 + ':' + key3 + ':';
							item.addOptURL("Play in 25 FPS", url+'25', "arrow_forward");
							item.addOptURL("Play in 50 FPS", url+'50', "arrow_forward");
						}

						item.addOptURL("Open Event '" + l_year + " - " + l_event + "'", PREFIX + ':f1tv:' + l_year + ':' + key2 + ':', "search");
						item.addOptURL("Open " + (l_year == "Feature" ? "Category" : "Season") + " '" + l_year + "'", PREFIX + ':f1tv:' + l_year + '::', "search");
					}
				}
				push_page(page, "hist");
				return;
			}
		}

		showtime.notify("Your watch history is empty.", 5);
		push_page(page, "hist");
		return;
	});

    plugin.addURI(PREFIX + ":f1cat:(.*):(.*)", function(page, site, section) 
	{

		page.flush();
		var date = new Date();
		var timestamp2 = parseInt(date.getTime()/1000);

		if(!f1_json || timestamp2-timestamp>timeout)
		{
			return_to = PREFIX + ":f1cat:"+site+":"+section;
			page.redirect(PREFIX + ":start"); 
			return;
		}
		
		if(site == "f1")
		{
			setPageHeader(page, 'Formula 1® - Video Categories');
			page.metadata.glwview =  res_path + "list2.view";
			for(var i in f1cat) 
			{
				page.appendItem(PREFIX + ":f1:" + i, "directory", {
					title: f1cat[i][1],
					icon: logo
				});
			}
			push_page(page, "f1ct");
			return;
		}

		if(site == "f1tv" && section == "ytv")
		{
			setPageHeader(page, 'Formula 1® & Sky Sports F1', "yt.svg");
			page.metadata.glwview =  res_path + "list.view";

			if(serv_json.f1_lytv)
			{
				var lytv = showtime.JSONDecode(serv_json.f1_lytv);
				for(var d = 0; d < lytv.length; d++)
				{
					title = lytv[d][3];
					ctitle = "";
					if(title.indexOf("|")>10)
					{
						title = title.substr(0, title.indexOf("|")-1).trim();
						ctitle = lytv[d][3].substr(lytv[d][3].indexOf("|")+1).trim();
					}
					var item = page.appendItem("ytp:video:"+lytv[d][1], 'video', {
						icon: "http://i.ytimg.com/vi/"+lytv[d][1]+"/mqdefault.jpg",
						title: title,
						description: lytv[d][3],
						duration: lytv[d][2],
						ctitle: (ctitle?new showtime.RichText(coloredStr(ctitle, 'AAAAAA', 2)):""),
					});
					if(serv_json.isaos)
						item.addOptURL('Play in YouTube', 'youtubeAT:'+lytv[d][1], 'arrow_forward');
				}
			}
		}

		if(site == "f1tv" && (section == "main" || section == "live"))
		{
			page.options.createMultiOpt('video2', 'Video Quality', 
			[
				['lq', 'Low',		 	(service.quality=="lq"?true:false)],
				['sd', 'SD',			(service.quality=="sd"?true:false)],
				['hd', '720p',			(service.quality=="hd"?true:false)],
				['fh', '1080p',			(service.quality=="fh"?true:false)]
			]
			, function(video2) {
			  user_video = video2;
			}, true);

			page.options.createMultiOpt('fps2', 'Video Framerate', 
			[
				['25', '25 FPS',		(service.fps=="25"?true:false)],
				['50', '50 FPS',		(service.fps=="50"?true:false)]
			]
			, function(fps2) {
			  user_fps = fps2;
			}, true);
			
			page.options.createMultiOpt('audio2', 'Audio / Language', 
			[
				['au', 'English', 	(service.audio=="au"?true:false)],
				['fx', 'FX', 		(service.audio=="fx"?true:false)],
				['es', 'Español',	(service.audio=="es"?true:false)],
				['de', 'Deutsch',	(service.audio=="de"?true:false)],
				['fr', 'Français',	(service.audio=="fr"?true:false)],
				['du', 'Dutch',		(service.audio=="du"?true:false)],
				['pt', 'Portuguese',(service.audio=="pt"?true:false)]
			]
			, function(audio2) {
			  user_audio = audio2;
			}, true);

			page.options.createMultiOpt('subs2', 'Subtitles', 
			[
				[1, 'On', 		(service.subs==true?true:false)],
				[0, 'Off', 		(service.subs==false?true:false)]
			]
			, function(subs2) {
			  user_sub = subs2;
			}, true);
		}

		if(site == "f1tv" && section == "main")
		{
			f1tv_add_main(page);
			push_page(page, "late");
		}

		if(site == "f1tv" && section == "live")
		{
			f1tv_add_live(page);
			push_page(page, "live");
		}
		
		if(site == "f1tv" && section == "vod")
		{
			setPageHeader(page, 'F1TV® - Archive', "f1tvlogo.png");	
			page.metadata.glwview =  res_path + "grid.view";

			for (var key in f1_json)
			{
				icon = logo;
				if( (key >= serv_json.f1_arch && key < 2099) || key>"A" )
					icon = serv_json.f1_imgs + "cat/" + key + ".jpg";
				page.appendItem(PREFIX + ':f1tv:' + key + '::', 'video', {
					icon: icon, //logo,
					title: (key=='Feature'?'Series':key)
				});
				if(key=='Feature')
					page.appendItem("", "separator", {title:""});
			}
			push_page(page, "vod");
				
			return;
		}
		
	});

	plugin.addURI(PREFIX + ":othertv", function(page) 
	{
		setPageHeader(page, 'Sports TV', "livetv.png");
		page.metadata.glwview =  res_path + "epg2.view";

		if(!serv_json)
		{
			return_to = PREFIX + ":othertv";
			page.redirect(PREFIX + ":start"); 
			return;
		}
		
		add_channels(page, 0, "", "");
		push_page(page, "sptv");
	});

	plugin.addURI(PREFIX + ":livetv", function(page) 
	{
		setPageHeader(page, 'Live Motorsports Today', "ms.png");
		page.metadata.glwview =  res_path + "epg2.view";

		if(!serv_json)
		{
			return_to = PREFIX + ":livetv";
			page.redirect(PREFIX + ":start"); 
			return;
		}
		var tv_live = showtime.JSONDecode(serv_json.tv_live);
		for (var ch in tv_live) 
		{

			c_start = tv_live[ch].start;
			n_start = tv_live[ch].end;
			var ct=new Date((c_start+service.offset*3600)*1000); ct = ct.toString().substr(11, 5);
			var nt=new Date((n_start+service.offset*3600)*1000); nt = nt.toString().substr(11, 5);

			page.appendItem(PREFIX+":tvch:"+tv_live[ch].ch+":"+escape(ct+" - "+tv_live[ch].event + " ("+tv_live[ch].descr+")"), 'video', {
				icon: img_path + "tv.png",
				title: tv_live[ch].event,
				description: new showtime.RichText(tv_live[ch].descr),
				ctitle: tv_live[ch].event + " ("+tv_live[ch].descr+")",
				cstart: c_start,
				cstop: n_start,
				chm: ct,

				ntitle: "End of Event",
				nstart: n_start,
				nhm: nt,
			});
		}
		push_page(page, "lvtv");
	});
	
	function add_channels(page, ignore, w1, w2)
	{
		var no_info = "No information available";
		var epg = null;

		if(ignore!=2)
		{
			if(serv_json.tv_prog)
				epg = showtime.JSONDecode(serv_json.tv_prog);
		}

		for (var ch in serv_json.ch) 
		{
			if(ignore==2)
			{
				if(serv_json.ch[ch][0]==0 && (serv_json.ch[ch][3].indexOf(PREFIX+":f1")>=0 || serv_json.ch[ch][3].indexOf("youtube:")>=0))
				{
					icon = (serv_json.ch[ch][1].indexOf('://')>=0?serv_json.ch[ch][1]:img_path + serv_json.ch[ch][1] + ".png");
					page.appendItem(serv_json.ch[ch][3], 'video', {
						icon: icon,
						title: serv_json.ch[ch][2],
						description: new showtime.RichText(serv_json.ch[ch][4]+race_date),
					});
				}
				continue;
			}
			
			var c_start = parseInt(Date.now()/1000)-1800, 
			c_stop = c_start+3600*4, 
			c_desc = no_info, 

			n_start = c_stop,
			n_desc = no_info, 

			t_start = n_start+3600*4, 
			t_desc = no_info,

			c_epg = -1;

			//if(serv_json.ch[ch][0]==1)
			{
				ch_now	= parseInt(Date.now()/1000);
				
				for(var j=0; j<epg.length; j++)
				{
					if( (serv_json.ch[ch][3] == epg[j].c) &&
						 ( (epg[j].s <= ch_now && epg[j].e >= ch_now ) 
							|| epg[j].s >= ch_now ) )
					{
						c_start	= epg[j].s;
						c_stop	= epg[j].e;
						c_desc	= epg[j].t;

						if( (j+1)<epg.length && serv_json.ch[ch][3] == epg[j+1].c)
						{
							n_start	= epg[j+1].s;
							n_desc	= epg[j+1].t;
						}

						if( (j+2)<epg.length && serv_json.ch[ch][3] == epg[j+2].c)
						{
							t_start	= epg[j+2].s;
							t_desc	= epg[j+2].t;
						}
						break;
					}
				}
			}

			var ct=new Date((c_start+service.offset*3600)*1000); ct = ct.toString().substr(11, 5);
			var nt=new Date((n_start+service.offset*3600)*1000); nt = nt.toString().substr(11, 5);
			var tt=new Date((t_start+service.offset*3600)*1000); tt = tt.toString().substr(11, 5);

			if(serv_json.ch[ch][0]==1 || serv_json.ch[ch][0]==2)
				page.appendItem(PREFIX + ':tvch'+(serv_json.ch[ch][0]=="1"?"":"2")+':'+ch+":"+escape(ct+" - "+c_desc + " ("+serv_json.ch[ch][2]+")"), 'video', {
					icon: serv_json.logo+serv_json.ch[ch][3]+".png",
					nows: serv_json.nows+serv_json.ch[ch][3]+".jpg",
					title: ct+" - "+c_desc + " ("+serv_json.ch[ch][2]+")",
					description: new showtime.RichText(ct+" - "+c_desc+"<br>"+nt+" - "+n_desc+"<br>"+tt+" - "+t_desc),

					ctitle: c_desc,
					cstart: c_start,
					cstop: n_start,
					chm: ct,

					ntitle: n_desc,
					nstart: n_start,
					nhm: nt,

					ttitle: t_desc,
					tstart: t_start,
					thm: tt,
				});

			else if(serv_json.ch[ch][0]==4)
				page.appendItem(serv_json.ch[ch][4], 'video', {
					icon: serv_json.logo+serv_json.ch[ch][3]+".png",
					nows: serv_json.nows+serv_json.ch[ch][3]+".jpg",
					title: ct+" - "+c_desc + " ("+serv_json.ch[ch][2]+")",
					description: new showtime.RichText(ct+" - "+c_desc+"<br>"+nt+" - "+n_desc+"<br>"+tt+" - "+t_desc),

					ctitle: c_desc,
					cstart: c_start,
					cstop: n_start,
					chm: ct,

					ntitle: n_desc,
					nstart: n_start,
					nhm: nt,

					ttitle: t_desc,
					tstart: t_start,
					thm: tt,
				});

			else if(serv_json.ch[ch][0]==0)
			{

				if(serv_json.ch[ch][3].indexOf(PREFIX+":")<0 && serv_json.ch[ch][3].indexOf("youtube:")<0)
				page.appendItem(
					"videoparams:" + showtime.JSONEncode({
						title: ct+" - "+c_desc + " ("+serv_json.ch[ch][2]+")",
						sources: [{
							url: serv_json.ch[ch][4],
							mimetype: "video/mpeg"
						}],
						icon: serv_json.logo+serv_json.ch[ch][3]+".png",
						no_fs_scan: true,
						no_subtitle_scan: true,
					}),
		
					'video', {
						icon: serv_json.logo+serv_json.ch[ch][3]+".png",
						nows: serv_json.nows+serv_json.ch[ch][3]+".jpg",
						title: ct+" - "+c_desc + " ("+serv_json.ch[ch][2]+")",
						description: new showtime.RichText(ct+" - "+c_desc+"<br>"+nt+" - "+n_desc+"<br>"+tt+" - "+t_desc),

						ctitle: c_desc,
						cstart: c_start,
						cstop: n_start,
						chm: ct,

						ntitle: n_desc,
						nstart: n_start,
						nhm: nt,

						ttitle: t_desc,
						tstart: t_start,
						thm: tt,
					});
			}
		}
	}
	
	plugin.addURI(PREFIX + ":f1login", function(page) 
	{
		setPageHeader(page, 'Sign-in to F1TV®');
		page.metadata.glwview =  res_path + "list2.view";
		f1_login(page, 0);
		page.flush();
		page.redirect(PREFIX + ":start"); 
	});
	
    function processStartPage(page) 
	{
		if(!service.f1login)
			store.token = null;
		
		else
		{
			if(!store.token)
			{
				page.appendItem(PREFIX + ':f1login', 'directory', {
					icon: f1tvlogo,
					title: "Sign-in to F1TV®"
				});
			}
			else
				f1_login(page, 0);		
		}
		
		page.appendItem(PREFIX + ':f1cat:f1tv:main', 'directory', {
			icon: f1tvlogo,
			title: "Live & Archive"
		});

		page.appendItem(PREFIX + ':standings::', 'directory', {
			icon: logo,
			title: "Standings"
		});

		page.appendItem(PREFIX + ':f1cat:f1:main', 'directory', {
			icon: logo,
			title: "Video"
		});

		page.appendItem(PREFIX + ':f1news::', 'directory', {
			icon: logo,
			title: "News"
		});

		page.appendItem("", "separator", {title:""});
 
		if(!(service.f1tvonly && store.token && service.f1login))
		{
			if(serv_json.ch)
			{
				add_channels(page, 2);
				
				if(serv_json.showo)
				page.appendItem(PREFIX + ':othertv', 'video', {
					icon: img_path + "livetv.png", 
					title: "Sports TV",
					description: new showtime.RichText(race_date),
				});
				if(serv_json.showt)
				page.appendItem(PREFIX + ':livetv', 'video', {
					icon: img_path + "ms.png", 
					title: "Motor Sport Events Today",
					description: new showtime.RichText(tvl_date),
				});
			}
		}
		else
			add_channels(page, 2);

		if(serv_json.f1_lytv)
		{
			page.appendItem("", "separator", {title:""});
			page.appendItem(PREFIX + ':f1cat:f1tv:ytv', 'directory', {
				icon: img_path + "yt.svg",
				title: "Latest from Formula 1® & Sky Sports F1"
			});
		}
		
		page.loading = false;
    }
	
	function decodeBase64(s) {
			var e={},i,b=0,c,x,l=0,a,r='',w=String.fromCharCode,L=s.length;
			var A="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
			for(i=0;i<64;i++){e[A.charAt(i)]=i;}
			for(x=0;x<L;x++){
				c=e[s.charAt(x)];b=(b<<6)+c;l+=6;
				while(l>=8){((a=(b>>>(l-=8))&0xff)||(x<(L-2)))&&(r+=w(a));}
			}
			return r;
	};
		
	function f1_login(page, forced)
	{
		if(!service.f1login)
		{
			store.token = null;
			store.sstat = 0;
			return 0;
		}
		
		var date = new Date();
		timestamp3 = parseInt(date.getTime()/1000);
		if(store.token && store.expire > (timestamp3+14400) && store.sstat>=0 && store.sstat<=2)
		{
			showtime.notify("Welcome back, "+store.fname+"!", 3);
			return 1;
		}
		
		store.token = null;
		store.sstat = 0;

		var credentials = plugin.getAuthCredentials("F1TV®", 'Please enter your username and password:', false, 'f1tv');
		
		if (credentials==null || credentials.rejected || !credentials.username || !credentials.password || forced) 
			credentials = plugin.getAuthCredentials("F1TV®", 'Please enter your username and password:', true, 'f1tv');

		if (credentials==null || credentials.rejected)
		{
			page.flush();
			page.redirect(PREFIX + ":start"); 
			return 0;
		}
	
		try
		{
			page.loading = true;
			data = showtime.JSONDecode(showtime.httpReq( ( ((user_f1ur || service.badregion) && serv_json.f1_api_u) ? serv_json.f1_api_u : serv_json.f1_api_a ), {
								headers: {
									"User-Agent":	serv_json.f1_log_u,
									"Accept":		"application/json, text/plain, */*",
									"Content-Type": "application/json",
									"Connection": 	"close",
									"apiKey":		serv_json.f1_api_h[0],
									"cd-systemid":	serv_json.f1_api_h[1],
									"CD-Language":	serv_json.f1_api_h[2]
								},
								caching: false,
								compression: true,
								nofail: true,
								postdata: '{"Login":"'+credentials.username.toString()+'", "Password": "'+credentials.password.toString()+'"}',
								method: 'POST',
							}).toString());

			if(data && data.Fault && data.Fault.Message)
			{
				showtime.trace("F1 Login Error: " + data.Fault.Message);
				showtime.notify("F1TV® Error: " + data.Fault.Message.replace("Exception of type '", "").replace("' was thrown.", ""), 10);
				if(data.Fault.Message.indexOf("Ascendon")>=0)
				{
					showtime.notify("F1TV® denies authorization attempts from your current IP address and/or location.", 10);
					if(!serv_json.f1_api_u)
					{
						showtime.message('Are you currently in <font size="3" color="#FF1010">Unsupported F1TV® Region</font>?<br><br>Obtain your Personal Key to avoid the use of VPN.', true, false);
					}
					else
					if( (!user_f1ur || !service.badregion) && serv_json.f1_api_u)
					{
						if(showtime.message('Are you currently in Unsupported F1TV® region?<br><br>Please enable the option in Settings:<br><br><font size="3" color="#FF1010">Use From Unsupported F1TV® Region</font><br><br>Retry?', true, false))
						{
							user_f1ur = true;
							service.badregion = true;

							data = showtime.JSONDecode(showtime.httpReq( ( (user_f1ur || service.badregion) ? serv_json.f1_api_u : serv_json.f1_api_a ), {
								headers: {
									"User-Agent":	serv_json.f1_log_u,
									"Accept":		"application/json, text/plain, */*",
									"Content-Type": "application/json",
									"Connection": 	"close",
									"apiKey":		serv_json.f1_api_h[0],
									"cd-systemid":	serv_json.f1_api_h[1],
									"CD-Language":	serv_json.f1_api_h[2]
								},
								caching: false,
								compression: true,
								nofail: true,
								postdata: '{"Login":"'+credentials.username.toString()+'", "Password": "'+credentials.password.toString()+'"}',
								method: 'POST',
							}).toString());

							if(data && data.Fault && data.Fault.Message)
							{
								showtime.trace("F1 Login Error: " + data.Fault.Message);
								showtime.notify("F1TV® Error: " + data.Fault.Message.replace("Exception of type '", "").replace("' was thrown.", ""), 10);
							}

							if(data && data.data && data.data.subscriptionToken)
							{
								showtime.message('F1TV® Sign-in Successful!<br><br>Please enable the option in Settings:<br><br><font size="3" color="#FF1010">Use From Unsupported F1TV® Region</font><br><br>to disable this message.', true, false);
							}
						}
					}
				}
			}

			token1		= data.data.subscriptionToken;

			if(data.data.subscriptionStatus && data.data.subscriptionStatus.trim().toLowerCase() == "active")
				store.sstat = 2;

			data = showtime.JSONDecode(decodeBase64(token1.split('.')[1]));
			
			store.fname = data.FirstName;
			store.lname = data.LastName;
			store.stype = data.SubscribedProduct.trim();

			if(store.stype)
			{
				if(store.stype.toLowerCase().indexOf("access")>=0) store.stype = "F1TV® Access";
				if(store.stype.toLowerCase().indexOf("pro")>=0) store.stype = "F1TV® Pro";

				if(store.sstat>0 && store.stype.toLowerCase().indexOf("pro")>=0)
					store.sstat = 1; // F1TV Pro
				else 
					store.sstat = 2; // F1TV Access
			}
			else
				store.sstat = 0;

			if(serv_json.f1_syn_2)
			{
				var date = new Date();
				store.token = token1;
				store.expire = parseInt(date.getTime()/1000)+14*86400;

				page.loading = false;
				if(forced)
				{
					page.flush();
					page.redirect(PREFIX + ":start"); 
				}
				return 1;
			}
			
			data = showtime.JSONDecode(showtime.httpReq(serv_json.f1_idn_a, {
								headers: {
									"User-Agent":	serv_json.f1_log_u,
									"Accept":		"application/json, text/plain, */*",
									"Content-Type": "application/json",
									"Connection": 	"close",
								},
								caching: false,
								compression: true,
								nofail: true,
								method: 'GET',
							}).toString());
			
			ident = data.objects[0].self;
			if(!ident) ident = serv_json.f1_idn_i;
			
			data = showtime.JSONDecode(showtime.httpReq(serv_json.f1_soc_a, {
								headers: {
									"User-Agent":	serv_json.f1_log_u,
									"Accept":		"application/json, text/plain, */*",
									"Content-Type": "application/json",
									"Connection": 	"close",
								},
								caching: false,
								compression: true,
								nofail: true,
								postdata: '{"identity_provider_url":"'+ident+'","access_token":"'+token1+'"}',
								method: 'POST',
							}).toString());
							
			token = data.token;

			data = showtime.JSONDecode(showtime.httpReq(serv_json.f1_syn_a, {
								headers: {
									"User-Agent":	serv_json.f1_log_u,
									"Accept":		"application/json, text/plain, */*",
									"Content-Type": "application/json",
									"Connection": 	"close",
									"Authorization":"JWT "+token,
								},
								caching: false,
								compression: true,
								nofail: true,
								method: 'GET',
							}).toString());
			
			if(token.length>=serv_json.f1_tok_l)
			{
				var token_a = showtime.JSONDecode(decodeBase64(token.split('.')[1]));
				store.token = token;
				store.expire = token_a.exp;

				page.loading = false;
				if(forced)
				{
					page.flush();
					page.redirect(PREFIX + ":start"); 
				}
				return 1;
			}
			else store.token = null;
		
		}
		catch (err){
			showtime.notify("Error occured while signing in to F1TV®!", 5);
			store.token = null;
		}
		page.loading = false;
		f1_login(page, 1);
		return 0;
	}

	function preInit(init)
	{
		var date = new Date();
		timestamp = parseInt(date.getTime()/1000);

		try
		{
			var serv_chk = showtime.JSONDecode(showtime.httpReq(service.apisrv, {
				postdata: service.key+app_ver+'chk--'+showtime.JSONEncode({h: showtime.deviceId}),
				method: 'POST',
				caching: false,
				noFail: true,
				compression: true,
			}));

			new_dat = 0;
			new_cur = 0;
			new_doc = 0;
			new_arc = 0;

			if(serv_chk && serv_chk.hash && data_hash && serv_chk.hash == data_hash.hash && data_store && data_store.json)
			{
				serv_json = data_store.json;
			}
			else
			{
				serv_json = showtime.JSONDecode(showtime.httpReq(service.apisrv, {
					postdata: service.key+app_ver+'ini--'+showtime.JSONEncode({h: showtime.deviceId}),
					method: 'POST',
					caching: false,
					noFail: true,
					compression: true,
				}));

				if(serv_json && serv_json.update)
				{
					return_to = null;
					return;
				}

				new_dat = 1;

				data_hash.hash = serv_chk.hash;
				data_store.json = serv_json;

				var new_data = "";
				if(serv_json.f1_hash_cur != data_hash_cur.hash)	{data_hash_cur.hash = serv_json.f1_hash_cur; new_data += "1"; new_cur = 1;} else new_data += "0";
				if(serv_json.f1_hash_doc != data_hash_doc.hash)	{data_hash_doc.hash = serv_json.f1_hash_doc; new_data += "1"; new_doc = 1;} else new_data += "0";
				if(serv_json.f1_hash_arc != data_hash_arc.hash)	{data_hash_arc.hash = serv_json.f1_hash_arc; new_data += "1"; new_arc = 1;} else new_data += "0";

				if(new_data!="000")
				{
					upd_json = showtime.JSONDecode(showtime.httpReq(service.apisrv, {
						postdata: service.key+app_ver+'ch'+new_data+showtime.JSONEncode({h: showtime.deviceId}),
						method: 'POST',
						caching: false,
						noFail: true,
						compression: true,
					}));
					
					if(upd_json)
					{
						if(upd_json.f1_json_cur) data_cur.data = upd_json.f1_json_cur;
						if(upd_json.f1_json_doc) data_doc.data = upd_json.f1_json_doc;
						if(upd_json.f1_json_arc) data_arc.data = upd_json.f1_json_arc;
					}
				}
			}

			if(serv_json)
			{
				if(serv_json.date)
					calendar = showtime.JSONDecode(serv_json.date);
				last = "";
				if(calendar.length && serv_json.next)
				{

					var date0 = new Date();
					var now0 = parseInt(date0.getTime()/1000)+service.offset*3600;
					live_start = 0;
					live_end = 0;
					live_msg = "";

					race_date = serv_json.next + calendar[0][2] + "<hr>";
					for(var d = 1; d < calendar.length; d++)
					{
						s_start = new Date((parseInt(calendar[d][0])+service.offset*3600)*1000);
						s_end = new Date((parseInt(calendar[d][1])+service.offset*3600)*1000);

						if(s_start.toString().substr(0, 10)!=last)
						{
							race_date += "<br>";
							last = s_start.toString().substr(0, 10);
						}
						race_date += s_start.toString().substr(0, 16)+" - " + s_end.toString().substr(11, 5) + "  " + calendar[d][2] + "<br>";
						
						if(now0 >= (parseInt(calendar[d][0])+service.offset*3600-600) && now0 <= (parseInt(calendar[d][1])+service.offset*3600)+600)
						{
							live_start = parseInt(calendar[d][0])+service.offset*3600-600;
							live_end = parseInt(calendar[d][1])+service.offset*3600+600;
							live_msg = (calendar[0][4]?calendar[0][4]+"\n\n":"")+s_start.toString().substr(11, 5)+" - " + s_end.toString().substr(11, 5) + "  ";
						}
					}
				}

				if(serv_json.tmo && serv_json.tmo>=60)
					timeout = serv_json.tmo;

				if(serv_json.tml && serv_json.tml>=60)
					timeout_live = serv_json.tml;

				if(serv_json.whm && serv_json.whm>1)
					hist_max = serv_json.whm;

				if(serv_json.f1_uad_2)
					io.httpInspectorCreate(serv_json.f1_uad_2, function(req) {
						req.setHeader('User-Agent', serv_json.f1_uag_2);
					});

				if(serv_json.skyp)
					calendar = showtime.JSONDecode(serv_json.skyp);
				last = "";
				if(calendar.length && serv_json.skyn)
				{
					skyp_date = serv_json.skyn + "<hr>";
					for(var d = 0; d < calendar.length; d++)
					{
						s_start = new Date((parseInt(calendar[d][0])+service.offset*3600)*1000);
						if(s_start.toString().substr(0, 10)!=last)
						{
							skyp_date += "<br>";
							last = s_start.toString().substr(0, 10);
						}
						skyp_date += s_start.toString().substr(0, 16) + " - " + calendar[d][2] + "<br>";
					}
				}

				if(serv_json.tv_live)
					calendar = showtime.JSONDecode(serv_json.tv_live);
				last = "";
				if(calendar.length)
				{
					tvl_date = "Motor Sport Events Today<hr>";
					for(var d = 0; d < calendar.length; d++)
					{
						s_start = new Date((parseInt(calendar[d].start)+service.offset*3600)*1000);
						if(s_start.toString().substr(0, 10)!=last)
						{
							tvl_date += "<br>";
							last = s_start.toString().substr(0, 10);
						}
						tvl_date += s_start.toString().substr(0, 16) + " - " + calendar[d].event + "<br>";
					}
				}

				if(serv_json.f1_whist && serv_json.f1_whist != "err" && serv_json.f1_whist != data_hist.data)
				{
					data_hist.data = serv_json.f1_whist;
				}
			}

			if(data_cur.data && data_doc.data && data_arc.data)
			{
				f1_json = showtime.JSONDecode("{" + data_doc.data + "," + data_cur.data + "," + data_arc.data + "}");
			}
			else
				return_to = null;

		}
		catch (err)
		{return_to = null;}

	}

	function main(page)
	{
		if(!return_to)
		{
			if(service.f1login && store.token)
				setPageHeader(page, store.fname+" "+store.lname+(store.sstat>0 ? " ("+store.stype+")":""), null, img_path + 'bg/B.jpg');
				
			else
				setPageHeader(page, "Formula 1®", null, img_path + 'bg/B.jpg');
		
			page.metadata.glwview =  res_path + "list2.view";
			page.entries = 0;
			page.loading = true;
		}

		if(service.f1login)
		{
			page.options.createAction('login', "Sign-in to F1TV® as different user", function() 
			{
				store.token = null;
				page.flush();
				f1_login(page, 1);
				return;
			});
		}		
		if(store.token && service.f1login)
		{
			page.options.createAction('logout', "Sign-out from F1TV®", function() 
			{
				store.token = null;
				page.flush();
				page.redirect(PREFIX + ":start"); 
				return;
			});
		}

		page.options.createAction('refresh', "Sync Event Data"+(service.ntf>0?" (auto in "+(timestamp?(parseInt((timeout_live-( parseInt(new Date().getTime()/1000)-timestamp))/60)):(parseInt(timeout_live/60)))+" min)":""), function() 
		{
			timestamp = 0;
			page.flush();
			page.redirect(PREFIX + ":start"); 
			return;
		});		

        page.options.createAction('update', "Update "+plugin.getDescriptor().title, function() 
		{
			page.metadata.glwview =  null;
			page.flush();
			showtime.notify("Updating, please wait...", 3);
			showtime.notify("Press [BACK] and restart the plugin after 15 seconds...", 10);
			showtime.notify("If you don't see the Formula 1 plugin icon - restart Movian.", 10);
			page.redirect(service.apisrv+PREFIX+'.zip');
			return;
        });

		try
		{
			var date = new Date();
			var timestamp2 = parseInt(date.getTime()/1000);
			
			if(!pre_init || timestamp2-timestamp>=600 || timestamp2-timestamp>=timeout || (service.key.length==14 && last_key != service.key) || service.ntf==0 || (serv_json && serv_json.update))
			{
				last_key = service.key;
				preInit(1);
				pre_init = 1;
			}

			if(serv_json)
			{
				if(serv_json.message1)
					showtime.notify(serv_json.message1, 12);
				if(serv_json.message2)
					showtime.notify(serv_json.message2, 12);
				if(serv_json.update)
				{
					update_app(page);
					return;
				}
			}
			else
			{
				page.loading = false;
				return_to = null;
				serv_json = null;
				return;
			}
		}
		catch(err){showtime.notify("API Server Error, retry later.", 5);page.loading = false;return_to = null;return;}

		if(serv_json.uids)
		{
			page.options.createInfo('user1', '', "User: "+serv_json.uids);
			page.options.createInfo('user2', '', "Created: "+serv_json.uini);
			page.options.createInfo('user3', '', "Expires: "+serv_json.uexp);
		}

		user_video = service.quality;
		user_fps   = service.fps;
		user_audio = service.audio;
		user_sub   = service.subs;
		user_f1ur  = service.badregion;
		
		if(!return_to)
			processStartPage(page);

		page.loading = false;
		
		if(service.ntf>0 && check_live_event(page, 1)) return;

		if(return_to)
		{
			return_uri = return_to;
			return_to = null;
			page.flush();
			page.redirect(return_uri);
		}
	};

	function push_page(page, tag, key, key2)
	{
		try
		{
			t_pages.unshift({page:page, src:page.source, tag:tag, key:key, key2:key2, items:page.getItems().length});

			if(t_pages.length>5) t_pages.splice(5);

			for(var p=0; p<t_pages.length; p++)
			{
				try
				{
					tp = t_pages[p].items + " " + t_pages[p].src;
					tp = t_pages[p].page.getItems();
				}
				catch (err)
				{
					t_pages.splice(p, 1);
					p--;
				}
			}
		}
		catch (err)	{;}
	}

    plugin.addURI(PREFIX + ":start", function(page)
	{
		if(return_to)
			main(page);
		else
		{
			t_pages.splice(0);
			main(page);
			push_page(page, "main");
		}
	});

	function check_live_event(page, show)
	{
		if(serv_json && serv_json.f1_live)
		{
			var live_now = showtime.JSONDecode(serv_json.f1_live);

			if(live_now && live_now.length>3)
			{
				l_temp = (show<2?show:1)+live_now[0]+" - "+live_now[1]+" - "+live_now[2];
				l_time = new Date((parseInt(live_now[3])+service.offset*3600)*1000);
				live_title = '<font size="6" color="#FF1010">'+(page?'':'FORMULA 1® ')+'LIVE EVENT</font>\n'+
					'<font size="2" color="#C0C0C0">'+l_time.toString().substr(0, 16) + '</font>\n\n'+
					live_now[1].substr(4)+' - '+live_now[2]+'\n'+
					'<font size="2" color="#C0C0C0">('+live_now[0]+' - Round '+parseInt(live_now[1].substr(1, 2))+')</font>\n\n'+
					(page == null ? 'Open Formula 1® app to join.' : 'Join now?');

				if(live_last!=l_temp && (service.ntf==2 || (service.ntf==1 && show!=2) ))
				{
					if(live_now[5]) user_audio = live_now[5];
					live_last = l_temp;

					if(showtime.message(live_title, true, (page == null ? false : true)))
					{
						if(page)
						{
							return_to = null;
							try
							{
								if(!live_now[4])
									page.redirect(PREFIX+":f1tv:"+live_now[0]+":"+live_now[1]+":"+live_now[2]);
								else
									page.redirect(live_now[4]);		
							}
							catch (err)
							{;}
						}
					}
					else
						showtime.notify("LIVE EVENT: "+live_last.substr(1), 3);

					return 1;
				}

				live_last = l_temp;
			}
			else
				live_last = "";
		}
		else
			live_last = "";

		return 0;
	}

	function hist_func()
	{
		try
		{
			if(last_hist != data_hist.data)
			{
				if(serv_json && serv_json.f1_shist)
				showtime.httpReq(service.apisrv, {
					postdata: service.key+app_ver+'whist'+showtime.JSONEncode({h: showtime.deviceId, wh:data_hist.data}),
					method: 'POST',
					caching: false,
					noFail: true,
					compression: true,
				});

				last_hist = data_hist.data;
			}
		}
		catch (err)
		{;}
	}

	function timer_func()
	{
		try
		{
			var date3 = new Date();
			var timestamp3 = parseInt(date3.getTime()/1000);
			
			if(!pre_init || timestamp3-timestamp>=timeout_live || (service.key.length==14 && last_key != service.key))
			{
				last_key = service.key;
				preInit(0);
				pre_init = 1;

				if( (new_cur || new_doc || new_arc) && service.ntf>0 )
				{
					var wh="FORMULA 1® - New content available in sections: ";
					if(new_doc) {wh+="(Series) ";}
					if(new_arc) {wh+="(Archive) ";}
					if(new_cur) {wh+="(Current Season)";}
					showtime.notify(wh, 5);
				}

				if(serv_json && serv_json.update) 
				{
					timestamp = 0; 
					new_dat = 0;
					new_cur = 0;
					new_doc = 0;
					new_arc = 0;
					showtime.notify("FORMULA 1® - New version is now available!", 5);
					t_page = get_page(null);
					if(t_page.page) 
					{
						showtime.message('<font size="3" color="#FF1010">FORMULA 1®</font><br><br>Update is required!<br><br>', true, false);
						update_app(t_page.page);
					}
					return;
				}
			}

			if(new_dat)
			{
				if(new_cur)
				{
					t_page = get_page("f1tv_event");
					if(t_page.page && t_page.key && t_page.key2)
					{
						t_page.page.flush();
						f1tv_add_events(t_page.page, t_page.key, t_page.key2);
					}
				}

				if(new_cur || new_doc || new_arc)
				{
					t_page = get_page("late");
					if(t_page.page && (new_cur || new_doc || new_arc))
					{
						t_page.page.flush();
						f1tv_add_main(t_page.page);
					}
				}

				t_page = get_page("live");
				if(t_page.page)
				{
					t_page.page.flush();
					f1tv_add_live(t_page.page);
				}

			}
		}
		catch (err)	{;}

		try
		{
			if(new_dat && service.ntf>0)
			{
				new_dat = 0;
				t_page = get_page(null);
				if(t_page.page)
					check_live_event(t_page.page, (t_page.type=="PAGE"?1:2));
				else
					check_live_event(null, 0);
			}
		}
		catch (err)
		{;}

		new_dat = 0;
		new_cur = 0;
		new_doc = 0;
		new_arc = 0;

		if(service.ntf==0) return;

		timer = setTimeout(timer_func, (timeout_live+(parseInt(Math.random()*60)))*1000);
	}

	function search(page, query, max_results)
	{
		var re = /([a-zA-Z0-9]{1,})/g;
		var match = re.exec(query);
		var words = [];
		while (match) 
		{
			w = match[1].toUpperCase();
			if(w.length==2)
			{
				if(w=="F1") {w="FORMULA"; words.push(" 1 ");}
				else if(w=="F2") {w="FORMULA"; words.push(" 2 ");}
				else if(w=="F3") {w="FORMULA"; words.push(" 3 ");}
			}
			if(w.length==1 && w=="W") {w="W SERIES"; words.push("W SERIES");}
			
			if(w.length>2 || (( (w.length==1 && words.length>0) || w.length==2) && w>="0" && w<="99"))
			{
				if(w.length<3) w = " "+w+ " ";
				words.push(w.toUpperCase().trim());
			}
			match = re.exec(query);
		}

		if(!words.length)
		{
			setPageHeader(page, "No Results for '"+query.trim()+"':", "f1tvlogo.png");
			showtime.notify('Please enter a longer phrase for search.', 5);
			return;
		}

		var entries = 0;
		for (var key0 in f1_json)
		{
			for (var key1 in f1_json[key0])
			{
				if(key1 == "TV") continue;
				for (var key2 in f1_json[key0][key1])
				{
					if(key2.indexOf("EXP-")==0) continue;
					ss = key0+" "+key1+" "+key2;
					ss = ss.toUpperCase();
					found = true;
					for(var i=0;i<words.length;i++)
					{
						found = found && (ss.indexOf(words[i])>=0)
						if(!found) break;
					}
					if(!found) continue;

					var attr = showtime.JSONDecode(f1_json[key0][key1][key2]);
					
					var has_audio="English";
					var aired = "";

					if(attr.sub.indexOf("E")>=0) has_audio = "CC • " + has_audio;
					if(attr.f50) has_audio = "50 FPS • " + has_audio;
					if(attr.aud.indexOf("X")>=0) has_audio+=" • FX";
					if(attr.aud.indexOf("S")>=0) has_audio+=" • Español";
					if(attr.aud.indexOf("G")>=0) has_audio+=" • Deutsch";
					if(attr.aud.indexOf("F")>=0) has_audio+=" • Français";
					if(attr.aud.indexOf("N")>=0) has_audio+=" • Dutch";
					if(attr.aud.indexOf("P")>=0) has_audio+=" • Portuguese";
					if(attr.air)
					{
						l_time = new Date((parseInt(attr.air)+service.offset*3600)*1000);
						aired = "<br><br>Added on: "+l_time.toString().substr(0, 16);
					}

					if(key2.substr(0, 4) == "YTP-")
					{
						yid = key2.match(/\[([0-9A-Za-z_-]{10}[048AEIMQUYcgkosw])\]-\[D(\d{2,})\]\-([\S\s]{2,60})/);
						if(yid.length==4)
						{
							if(attr.air)
							{
								l_time = new Date((parseInt(attr.air)+service.offset*3600)*1000);
								aired = "<br><br>Added on: "+l_time.toString().substr(0, 16);
							}

							l_year = key0;
							l_event = key1.replace("R00 ", "").replace("R99 ", "");
							if(l_event == "Barcelona" || key1.indexOf("R00 Sakhir")>=0) l_event = "Pre-Season Test";
							l_session = yid[3]; if(l_year!="Feature") l_title = l_year + " - " + l_event + " - " + l_session; else l_title = l_session; l_title = l_title.replace(" • Support Series", "");

							var item = page.appendItem("ytp:video:"+yid[1], 'video', {
								icon: "http://i.ytimg.com/vi/"+yid[1]+"/mqdefault.jpg",
								title: l_title,
								duration: parseInt(yid[2]),
								ctitle: new showtime.RichText(coloredStr('YouTube • English', 'AAAAAA', 2)),
								tagline: new showtime.RichText(yid[3]+aired),

							});
							if(serv_json.isaos)
								item.addOptURL('Play in YouTube', 'youtubeAT:'+yid[1], 'arrow_forward');

							item.addOptURL("Open Event '" + l_year + " - " + l_event + "'", PREFIX + ':f1tv:' + l_year + ':' + key1 + ':', "search");
							item.addOptURL("Open " + (l_year == "Feature" ? "Category" : "Season") + " '" + l_year + "'", PREFIX + ':f1tv:' + l_year + '::', "search");

							entries++;
							if(entries>=max_results) break;
						}
						continue;
					}

					l_year = key0;
					l_event = key1.replace("R00 ", "").replace("R99 ", "");
					if(l_event == "Barcelona" || key1.indexOf("R00 Sakhir")>=0) l_event = "Pre-Season Test";
					l_session = key2; if(l_year!="Feature") l_title = l_year + " - " + l_event + " - " + l_session; else l_title = l_session; l_title = l_title.replace(" • Support Series", "");

					var item = page.appendItem(PREFIX + ':f1tv:' + key0 + ':' + key1 + ':' + key2, 'video', {
						icon: serv_json.f1_imgs+key0+"/"+key1.replace(/\s/g, "%20")+"%20-%20"+key2.replace(/\s/g, "%20")+".jpg",
						title: (attr.dur==0?new showtime.RichText(coloredStr(l_title, 'ff1010')):l_title),
						tagline: new showtime.RichText(l_year + " - " + l_event+"<br><br>"+l_session+aired),
						duration: attr.dur,
						description: (attr.d?attr.d:""),
						ctitle: new showtime.RichText(coloredStr(has_audio, 'AAAAAA', 2)),
					});

					if(attr && attr.f50)
					{
						url = PREFIX + ':f1tv_fps:' + key0 + ':' + key1 + ':' + key2 + ':';
						item.addOptURL("Play in 25 FPS", url+'25', "arrow_forward");
						item.addOptURL("Play in 50 FPS", url+'50', "arrow_forward");
					}

					item.addOptURL("Open Event '" + l_year + " - " + l_event + "'", PREFIX + ':f1tv:' + l_year + ':' + key1 + ':', "search");
					item.addOptURL("Open " + (l_year == "Feature" ? "Category" : "Season") + " '" + l_year + "'", PREFIX + ':f1tv:' + l_year + '::', "search");

					entries++;

					if(entries>=max_results) break;
				}
				if(entries>=max_results) break;
			}
			if(entries>=max_results) break;
		}
		return entries;
	}

	plugin.addURI(PREFIX + ":search:(.*)", function(page, query) 
	{
		var date = new Date();
		var timestamp2 = parseInt(date.getTime()/1000);
		
		if(!f1_json || timestamp2-timestamp>timeout)
		{
			return_to = PREFIX + ":search:"+query;
			page.redirect(PREFIX + ":start"); 
			return;
		}
		setPageHeader(page, "Search Results for '"+query+"':", "f1tvlogo.png");
		page.metadata.glwview =  res_path + "list.view";

		entries = search(page, query, 50);
		push_page(page, "srch");

		setPageHeader(page, "Found "+entries+" Results for '"+query.trim()+"':", "f1tvlogo.png");
	});


	function get_icon(key0, key1, ss)
	{
		icon = serv_json.f1_imgs+key0+"/"+key1.replace(" • Support Series", "").replace(/\s/g, "%20")+".jpg";
		if(f1_json[key0] && f1_json[key0][key1])
		{
			if(key1.indexOf("Support Series")>0)
			{
				if(f1_json[key0][key1]["Formula 2 • Feature Race"])
					icon = serv_json.f1_imgs+key0+"/"+(key1+" - Formula 2 • Feature Race").replace(/\s/g, "%20")+".jpg";
				else if(f1_json[key0][key1]["Formula 2 • Sprint Race 1"])
					icon = serv_json.f1_imgs+key0+"/"+(key1+" - Formula 2 • Sprint Race 1").replace(/\s/g, "%20")+".jpg";
				else if(f1_json[key0][key1]["Formula 2 • Qualifying"])
					icon = serv_json.f1_imgs+key0+"/"+(key1+" - Formula 2 • Qualifying").replace(/\s/g, "%20")+".jpg";
				else if(f1_json[key0][key1]["Formula 3 • Race 1"])
					icon = serv_json.f1_imgs+key0+"/"+(key1+" - Formula 3 • Race 1").replace(/\s/g, "%20")+".jpg";
				else if(f1_json[key0][key1]["Formula 3 • Qualifying"])
					icon = serv_json.f1_imgs+key0+"/"+(key1+" - Formula 3 • Qualifying").replace(/\s/g, "%20")+".jpg";
				else if(f1_json[key0][key1]["Formula 2 • Practice"])
					icon = serv_json.f1_imgs+key0+"/"+(key1+" - Formula 2 • Practice").replace(/\s/g, "%20")+".jpg";
				else if(f1_json[key0][key1]["Formula 3 • Practice"])
					icon = serv_json.f1_imgs+key0+"/"+(key1+" - Formula 3 • Practice").replace(/\s/g, "%20")+".jpg";
				else if(f1_json[key0][key1]["Porsche Supercup • Race"])
					icon = serv_json.f1_imgs+key0+"/"+(key1+" - Porsche Supercup • Race").replace(/\s/g, "%20")+".jpg";
				else if(f1_json[key0][key1]["Porsche Supercup • Qualifying"])
					icon = serv_json.f1_imgs+key0+"/"+(key1+" - Porsche Supercup • Qualifying").replace(/\s/g, "%20")+".jpg";
				else if(f1_json[key0][key1]["Porsche Supercup • Practice"])
					icon = serv_json.f1_imgs+key0+"/"+(key1+" - Porsche Supercup • Practice").replace(/\s/g, "%20")+".jpg";
				else if(f1_json[key0][key1]["Formula 2 • Feature • Highlights"])
					icon = serv_json.f1_imgs+key0+"/"+(key1+" - Formula 2 • Feature • Highlights").replace(/\s/g, "%20")+".jpg";
				else if(f1_json[key0][key1]["Porsche Supercup • Race • Highlights"])
					icon = serv_json.f1_imgs+key0+"/"+(key1+" - Porsche Supercup • Race • Highlights").replace(/\s/g, "%20")+".jpg";
				else if(f1_json[key0][key1]["W Series • Race • Highlights"])
					icon = serv_json.f1_imgs+key0+"/"+(key1+" - W Series • Race • Highlights").replace(/\s/g, "%20")+".jpg";
				else if(f1_json[key0][key1]["W Series • Race 1 • Highlights"])
					icon = serv_json.f1_imgs+key0+"/"+(key1+" - W Series • Race 1 • Highlights").replace(/\s/g, "%20")+".jpg";				
				if(ss=="ss") return icon;
			}

			if(!f1_json[key0][key1]["Race"])
			{
				if(f1_json[key0][key1]["Review"])
					icon = serv_json.f1_imgs+key0+"/"+(key1+" - Review").replace(/\s/g, "%20")+".jpg";
				if(f1_json[key0][key1]["Race • Review"])
					icon = serv_json.f1_imgs+key0+"/"+(key1+" - Race • Review").replace(/\s/g, "%20")+".jpg";
				else
				if(f1_json[key0][key1]["Race • Highlights"])
					icon = serv_json.f1_imgs+key0+"/"+(key1+" - Race • Highlights").replace(/\s/g, "%20")+".jpg";
			}
		}
		return icon;
	}

	function search_events(page, q, descr)
	{
		var entries = 0;
		var srch = [];

		for(var i=0; i<tracks.length; i++)
		{
			if(tracks[i][0].toUpperCase().indexOf(q.src1.toUpperCase())==0 || tracks[i][1].toUpperCase().indexOf(q.src1.toUpperCase())==0)
				srch.push(tracks[i], tracks[i]);
		}

		for(var i=0; i<countries.length; i++)
		{
			if(countries[i][0].toUpperCase().indexOf(q.src1.toUpperCase())==0)
				srch.push([countries[i][0], countries[i][0]]);
		}

		if(!srch.length) srch.push(q.src1, q.tagl);

		if(q.cnt)
		for (var key0 in f1_json)
		{
			if(key0>q.year) continue;
			for (var key1 in f1_json[key0])
			{
				if(q.ignr && key1.toUpperCase().indexOf(q.ignr.toUpperCase())>=0) continue;

				found = false;
				s_venue = q.src1;
				for(var i=0; i<srch.length; i++)
				{
					s_country = (q.tagl?q.tagl:srch[i][1]);
					if(key1.toUpperCase().indexOf(srch[i][0].toUpperCase())==4 || key1.toUpperCase().indexOf(srch[i][1].toUpperCase())==4) 
					{
						s_venue = key1.substr(4);
						found = true;
						break;
					}
				}
				if(!found) continue;

				if(s_venue != srch[i][1]) s_venue = s_venue + ", " + srch[i][1];
				s_venue = s_venue.replace(" • Support Series", "");

				icon = get_icon(key0, key1, "f1");
				title = key1.replace("R00 ", "").replace("R99 ", "");
				if(title == "Barcelona" || key1.indexOf("R00 Sakhir")>=0) title = "Pre-Season Test";
				var item = page.appendItem(PREFIX + ':f1tv:' + key0 + ':' + key1 + ':', 'video', {
					icon: icon,
					title: q.prfx+key0+(key1.indexOf("Support Series")>0?" FIA SUPPORT SERIES - ":" FORMULA 1® - ")+s_country.toUpperCase(),
					tagline: key0 + " - " + title,
					description: new showtime.RichText(q.desc?q.desc:descr),
					ctitle: new showtime.RichText(coloredStr((key1.indexOf("Support Series")>0?"":(key1.substr(1,2)=="00"?key0+" Pre-Season Test":"Round "+key1.substr(1,2))+" - ")+s_venue, 'AAAAAA', 2)),
				});

				item.addOptURL("Open Event '" + key0 + " - " + title + "'", PREFIX + ':f1tv:' + key0 + ':' + key1 + ':', "search");
				item.addOptURL("Open Season '" + key0 + "'", PREFIX + ':f1tv:' + key0 + '::', "search");

				entries++;

				if(entries>=q.cnt) break;
			}
			if(entries>=q.cnt) break;
		}

		if(!entries && !q.cnt)
		{
			key0 = q.year;
			key1 = q.rnd+" "+q.src1;
			if(q.icon) icon = serv_json.f1_imgs+key0+"/"+q.icon.replace(/\s/g, "%20")+".jpg";
			else
			{
				if(key1.indexOf("Support Series")>0)
					icon = get_icon(key0, key1, "ss");
				else
					icon = get_icon(key0, key1, "f1");
			}
			s_country = (q.tagl?q.tagl:srch[0][1]);
			s_venue = q.src1;
			if(s_venue != srch[0][1]) s_venue = s_venue + ", " + s_country;//srch[0][1];
			s_venue = s_venue.replace(" • Support Series", "");
			title = key1.replace("R00 ", "").replace("R99 ", "");
			if(title == "Barcelona" || key1.indexOf("R00 Sakhir")>=0) title = "Pre-Season Test";
			var item = page.appendItem(PREFIX + ':f1tv:' + key0 + ':' + key1 + ':', 'video', {
				icon: icon,
				title: q.prfx+key0+(key1.indexOf("Support Series")>0?" FIA SUPPORT SERIES - ":" FORMULA 1® - ")+s_country.toUpperCase(),
				tagline: key0 + " - " + title,
				description: new showtime.RichText(q.desc?q.desc:descr),
				ctitle: new showtime.RichText(coloredStr((key1.indexOf("Support Series")>0?"":(key1.substr(1,2)=="00"?key0+" Pre-Season Test":"Round "+key1.substr(1,2))+" - ")+s_venue, 'AAAAAA', 2)),
			});

			item.addOptURL("Open Event '" + key0 + " - " + title + "'", PREFIX + ':f1tv:' + key0 + ':' + key1 + ':', "search");
			item.addOptURL("Open Season '" + key0 + "'", PREFIX + ':f1tv:' + key0 + '::', "search");
		}
	}

	function get_page(tag)
	{
		r = { page: null, type: null };

		if(t_pages && t_pages.length)
		{
			for(var p=0; p<t_pages.length; p++)
			{
				try
				{
					tp = t_pages[p].items + " " + t_pages[p].src;
					tp = t_pages[p].page.getItems();
				}
				catch (err)
				{
					t_pages.splice(p, 1);
					p--;
					continue;
				}
			}
		}

		if(t_pages && t_pages.length)
		{
			if(tag==null)
			{
				r.page = t_pages[0].page;
				r.type = (t_pages[0].src.toString().indexOf("videoparams")==0?"VIDEO":"PAGE");
				r.key  = t_pages[0].key;
				r.key2 = t_pages[0].key2;
			}
			else
			{
				for(var p=0; p<t_pages.length; p++)
				{
					if(t_pages[p].tag == tag)
					{
						r.page = t_pages[p].page;
						r.type = (t_pages[p].src.toString().indexOf("videoparams")==0?"VIDEO":"PAGE");
						r.key  = t_pages[p].key;
						r.key2 = t_pages[p].key2;
						break;
					}
				}
			}
		}
		return r;
	}

}) (this);
